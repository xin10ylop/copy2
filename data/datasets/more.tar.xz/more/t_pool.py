import sys, json, base64
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month"); sys.path.insert(0, SP + "/rivalpnl")
import tri, common as C
Q = json.load(open("quotes.json"))
# a class-A buy (multihop from wSOL): read its multi_hop_swap accounts
import importlib
o = [q for q in Q if q["cls"] == "A"][0]
tx = tri.rpc("getTransaction", [o["sig"], {"encoding": "json", "maxSupportedTransactionVersion": 1, "commitment": "confirmed"}])
print("version", tx.get("version"))
ks = tx["transaction"]["message"]["accountKeys"]
PAMM = "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA"
for ix in tx["transaction"]["message"]["instructions"]:
    if ks[ix["programIdIndex"]] == PAMM:
        acc = [ks[i] for i in ix["accounts"]]
        print(len(acc), acc[16:])
        pool = acc[16 + 2]
a = tri.rpc("getAccountInfo", [pool, {"encoding": "base64"}])
d = base64.b64decode(a["value"]["data"][0]); print(a["value"]["owner"], len(d), d[:8].hex())
for off in (11, 43, 75, 107, 139, 171):
    print(off, C.b58e(d[off:off + 32]))
