| paid in | buys | P1 its net | P2 its net | its route | wSOL pools (canonical) | deepest SOL side | 1 SOL impact | WBTC pools | routable (2 hops) |
|---|---|---|---|---|---|---|---|---|---|
| PUMP | 86 | +32.30 (54) | +8.92 (32) | direct 56, 2-hop 30 | 23 (no) | 17.4 | 5.4% | 0 (no) | no |
| CARDS | 80 | +22.25 (80) | +0.00 (0) | direct 77, 2-hop 1, 3-hop 2 | 0 (no) | - | - | 0 (no) | no |
| ZEC (A7bd) | 23 | +3.40 (7) | +1.93 (16) | direct 23 | 1 (no) | 0.0 | 96.3% | 0 (no) | no |
| TTWO | 23 | +10.30 (15) | +0.07 (8) | direct 15, 2-hop 8 | 0 (no) | - | - | 0 (no) | no |
| XMR (WXMR) | 15 | +6.48 (9) | +0.70 (6) | direct 15 | 0 (no) | - | - | 0 (no) | no |
| SPCX | 14 | -1.00 (7) | -0.51 (7) | direct 13, 2-hop 1 | 0 (no) | - | - | 0 (no) | no |
| Pren1F | 11 | +3.10 (8) | -0.57 (3) | direct 10, 2-hop 1 | 0 (no) | - | - | 0 (no) | no |
| USDC | 10 | +7.11 (8) | +2.65 (2) | direct 9, 2-hop 1 | 117 (no) | 28212.3 | 0.0% | 0 (no) | no |
| WETH | 7 | -0.56 (3) | -0.17 (4) | direct 7 | 1 (no) | 0.0 | 98.9% | 0 (no) | no |
| DJTu | 7 | +0.00 (0) | -2.03 (7) | direct 7 | 0 (no) | - | - | 0 (no) | no |
| 42 other tokens | 92 | | | | canonical: 1 | | | | |
