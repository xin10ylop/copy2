import sys, json, base64, time
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month")
import tri
PAMM = "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA"
WSOL = "So11111111111111111111111111111111111111112"
for base, quote in (("2gLnaQN8Y73Qc62gMmX6WtJQjFnbvE7vgzUJ37WJpump", WSOL), ("pumpCmXqMfrsAkQ5r49WcJnRayYRqmXz6ae8H7H9Dfn", WSOL), (WSOL, "pumpCmXqMfrsAkQ5r49WcJnRayYRqmXz6ae8H7H9Dfn")):
    t = time.time()
    r = tri.rpc("getProgramAccounts", [PAMM, {"encoding": "base64", "dataSlice": {"offset": 0, "length": 203},
              "filters": [{"memcmp": {"offset": 43, "bytes": base}}, {"memcmp": {"offset": 75, "bytes": quote}}]}], cache=False)
    print(base[:8], quote[:8], len(r), round(time.time() - t, 1), "s", [x["pubkey"] for x in r][:5])
