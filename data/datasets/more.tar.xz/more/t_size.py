import sys, json, base64, collections
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month")
import tri
QR = json.load(open(SP + "/h9long/qual_routes.json"))
Q = {q["sig"]: q for q in json.load(open("quotes.json"))}
res = collections.defaultdict(list)
for q in QR:
    n = (q.get("mh") or {}).get("n", 0)
    res[n].append(q["sig"])
for n, sigs in sorted(res.items()):
    for s in sigs[:3]:
        tx = tri.rpc("getTransaction", [s, {"encoding": "base64", "maxSupportedTransactionVersion": 1, "commitment": "confirmed"}])
        raw = base64.b64decode(tx["transaction"][0])
        print(n, "hops", tx.get("version"), len(raw), "bytes", raw[64 + 1] if len(raw) > 66 else None, s[:10])
