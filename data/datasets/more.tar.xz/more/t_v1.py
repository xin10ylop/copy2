import sys, json, base64
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month")
import tri
s = "uzJ56NduFH3ZWpxio6Rug9xK4XRkNhhBgQrA2EdiVAVk8sRsL6qMfLux185tUEptHeAWcew9GaQ44p9Yt23DGgr"
tx = tri.rpc("getTransaction", [s, {"encoding": "base64", "maxSupportedTransactionVersion": 1, "commitment": "confirmed"}])
raw = base64.b64decode(tx["transaction"][0])
print(len(raw), raw[:4].hex(), raw[64:80].hex(), raw[-80:].hex())
txj = tri.rpc("getTransaction", [s, {"encoding": "json", "maxSupportedTransactionVersion": 1, "commitment": "confirmed"}])
m = txj["transaction"]["message"]
print(m["header"], len(m["accountKeys"]), len(m["instructions"]), "alt" , m.get("addressTableLookups"))
for ix in m["instructions"]:
    print(m["accountKeys"][ix["programIdIndex"]][:10], len(ix["accounts"]), len(base64.b64decode(ix["data"]) if False else ix["data"]))
print(len(txj["transaction"]["signatures"]), txj["meta"]["fee"], txj["meta"].get("computeUnitsConsumed"))
