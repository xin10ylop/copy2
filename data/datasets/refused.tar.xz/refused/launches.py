# How many in-class launches a day? A create_v2 transaction's accounts: find one whose signatures are only creates
# (pump's mint authority), count its signatures over a window, and sample them for the class (create_v2, not mayhem,
# not cashback, SOL quote). Also our real failed-buy cost (the fee of our 6042-refused buys).
import sys, json, collections, time
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month"); sys.path.insert(0, "/home/user/rugsnipe/analysis/scripts/strategy")
import tri, operators_refresh as orf
L = json.load(open(SP + "/refused/live.json"))["mine"]
fees = [a["fee"] for v in L.values() for a in v if a.get("code") == "6042"]
print("our refused buys:", len(fees), "fee lamports: min", min(fees), "median", sorted(fees)[len(fees) // 2], "max", max(fees))
m = sorted(L)[3]; bc = orf.bonding_curve(m)
sig = None; before = None
for _ in range(30):
    o = {"limit": 1000}
    if before: o["before"] = before
    pg = tri.rpc("getSignaturesForAddress", [bc, o], cache=False)
    if not pg: break
    sig = pg[-1]["signature"]; before = sig
    if len(pg) < 1000: break
tx = tri.rpc("getTransaction", [sig, {"encoding": "json", "maxSupportedTransactionVersion": 1, "commitment": "confirmed"}], cache=False)
keys = tx["transaction"]["message"]["accountKeys"] + (tx["meta"].get("loadedAddresses") or {}).get("readonly", [])
print("create tx accounts:", [k[:10] for k in keys])
print(" ".join(l for l in tx["meta"]["logMessages"] if "Instruction" in l)[:300])
