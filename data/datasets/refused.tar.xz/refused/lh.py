import sys, json, collections
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month")
import tri
LH = "L2TExMFKdjpN9kozasaurPirfHy9P8sbXoAN1qA3S95"
a = tri.rpc("getAccountInfo", [LH, {"encoding": "base64"}], cache=False)
v = a["value"]; print("owner", v["owner"], "executable", v["executable"], "lamports", v["lamports"])
sigs = tri.rpc("getSignaturesForAddress", [LH, {"limit": 200}], cache=False)
print("recent txs", len(sigs), "newest", sigs[0]["blockTime"], "oldest", sigs[-1]["blockTime"], "errs", sum(1 for s in sigs if s.get("err")))
cus = []; disc = collections.Counter(); progs = collections.Counter()
for s in sigs[:40]:
    tx = tri.rpc("getTransaction", [s["signature"], {"encoding": "json", "maxSupportedTransactionVersion": 1, "commitment": "confirmed"}], cache=False)
    if not tx: continue
    m = tx["transaction"]["message"]; la = tx["meta"].get("loadedAddresses") or {}
    keys = m["accountKeys"] + la.get("writable", []) + la.get("readonly", [])
    for ix in m["instructions"]:
        p = keys[ix["programIdIndex"]]; progs[p[:8]] += 1
        if p == LH:
            import base58; d = base58.b58decode(ix["data"]); disc[d[0]] += 1
    lm = tx["meta"]["logMessages"]
    for i, l in enumerate(lm):
        if l.startswith(f"Program {LH} consumed"): cus.append(int(l.split("consumed ")[1].split(" ")[0]))
print("lighthouse CU per ix (sample):", sorted(cus)[:5], "median", sorted(cus)[len(cus)//2] if cus else None, "max", max(cus) if cus else None)
print("ix discriminators (first byte):", disc.most_common(10)); print("programs in those txs:", progs.most_common(12))
