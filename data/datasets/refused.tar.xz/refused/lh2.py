import sys, json, collections, base58
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month")
import tri
LH = "L2TExMFKdjpN9kozasaurPirfHy9P8sbXoAN1qA3S95"; PUMP = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P"
sigs = tri.rpc("getSignaturesForAddress", [LH, {"limit": 400}], cache=False)
shown = 0; signers = collections.Counter(); pat = collections.Counter(); err = collections.Counter()
for s in sigs:
    tx = tri.rpc("getTransaction", [s["signature"], {"encoding": "json", "maxSupportedTransactionVersion": 1, "commitment": "confirmed"}], cache=False)
    if not tx: continue
    m = tx["transaction"]["message"]; la = tx["meta"].get("loadedAddresses") or {}
    keys = m["accountKeys"] + la.get("writable", []) + la.get("readonly", [])
    seq = []
    for ix in m["instructions"]:
        p = keys[ix["programIdIndex"]]
        if p == LH:
            d = base58.b58decode(ix["data"]); acc = [keys[a] for a in ix["accounts"]]
            seq.append(("LH", d[0], d.hex()[:60], [a[:6] for a in acc]))
        else: seq.append((p[:6],))
    if not any(x[0] == "6EF8rr" for x in seq): continue
    signers[keys[0][:8]] += 1
    pat[tuple((x[0], x[1]) if x[0] == "LH" else x[0] for x in seq)] += 1
    e = tx["meta"].get("err"); err[json.dumps(e)[:60]] += 1
    if shown < 6:
        shown += 1; print(keys[0][:8], json.dumps(e)[:80]); [print("   ", x) for x in seq]
        print("    logs:", [l for l in tx["meta"]["logMessages"] if "L2TE" in l or "ssert" in l or "rror" in l][:4])
print("pump txs with lighthouse by signer:", signers.most_common(10))
print("patterns:", pat.most_common(6)); print("errors:", err.most_common(5))
