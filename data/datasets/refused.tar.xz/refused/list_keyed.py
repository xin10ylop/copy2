import json, os
exec(open("/home/user/rugsnipe/analysis/research/2026-10-27/refused/eng.py").read())
sel = [r["m"] for r in rows if r["tip"] >= 2e6 or r["sol"] >= 2.0]
rest = [r["m"] for r in rows if r["m"] not in set(sel)]
json.dump(sel, open(SP + "/refused/five_keyed.json", "w")); json.dump(rest, open(SP + "/refused/five_rest.json", "w"))
print(len(sel), "keyed;", len(rest), "other his buys at create + 0/1")
