import sys
exec(open("/home/user/rugsnipe/analysis/research/2026-10-27/refused/eng.py").read())
import collections
sel = [r for r in rows if r["tip"] >= 2e6 or r["sol"] >= 2.0]
c = collections.Counter()
for r in sel:
    tend = max(x[0] for x in r["seq"]) - r["cs"]
    sold = r["s"] is not None and r["s"]["slot"] - r["cs"] <= r["H"] - 1
    c[(r["day"], "exact" if (tend >= r["H"] - 1 or sold) else "STALE")] += 1
print(sorted(c.items()))
print("our create-slot landings (positions after the create), deciles:", dec)
