# How do the copy_more wallets open their token accounts? (a predictable address would let a ghost assert on it)
import sys, json
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month")
import tri
for w in ("JBokzLFRg8CEcThrjweWa9WoZoZPYitRSVffXuxdHHVu", "3yrJE1A8dgSuy5NLimG5GSYxA6wMkvnAYLD9Y4xR2fjJ", "H9kuqGKNYgPFYCA17uUTkaqXGum7MK8y1GwbS7cxsjDg", "CxyKYmQoaYLCds6puxSbWndk6ktqax8PwAeq8enRzph8", "D5BDDkBtjjva35nwu45WfmZgytsog9GST2tHQaZUYuFX"):
    sigs = tri.rpc("getSignaturesForAddress", [w, {"limit": 30}], cache=False)
    for s in sigs:
        if s.get("err"): continue
        tx = tri.rpc("getTransaction", [s["signature"], {"encoding": "jsonParsed", "maxSupportedTransactionVersion": 1, "commitment": "confirmed"}], cache=False)
        if not tx: continue
        logs = " ".join(tx["meta"]["logMessages"] or [])
        if "Buy" not in logs: continue
        ins = tx["transaction"]["message"]["instructions"]
        inner = [i for g in tx["meta"].get("innerInstructions") or [] for i in g["instructions"]]
        show = []
        for i in ins + inner:
            p = i.get("parsed")
            if isinstance(p, dict) and p.get("type") in ("createAccountWithSeed", "createAccount", "initializeAccount3", "initializeAccount", "create", "createIdempotent"):
                show.append((i.get("program"), p["type"], {k: (v if not isinstance(v, str) or len(v) < 50 else v[:12]) for k, v in (p.get("info") or {}).items() if k in ("base", "seed", "newAccount", "account", "owner", "mint", "wallet", "source")}))
        progs = [i.get("programId", "")[:6] for i in ins]
        print(w[:8], "top programs", progs[:8]); [print("    ", x) for x in show[:4]]
        break
