# Lighthouse in pump transactions: which accounts are asserted (owner of the asserted token account vs the signer).
import sys, json, collections, base58
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month")
import tri
LH = "L2TExMFKdjpN9kozasaurPirfHy9P8sbXoAN1qA3S95"; PUMP = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P"
seen = collections.Counter(); kinds = collections.Counter(); before = None; n = 0; ex = []
for _ in range(4):
    o = {"limit": 1000}
    if before: o["before"] = before
    sigs = tri.rpc("getSignaturesForAddress", [LH, o], cache=False); before = sigs[-1]["signature"]
    for s in sigs[::4]:
        tx = tri.rpc("getTransaction", [s["signature"], {"encoding": "json", "maxSupportedTransactionVersion": 1, "commitment": "confirmed"}], cache=False)
        if not tx: continue
        m = tx["transaction"]["message"]; la = tx["meta"].get("loadedAddresses") or {}
        keys = m["accountKeys"] + la.get("writable", []) + la.get("readonly", [])
        if PUMP not in keys: continue
        n += 1; signer = keys[0]
        toks = {b["accountIndex"]: b.get("owner") for b in (tx["meta"].get("preTokenBalances") or []) + (tx["meta"].get("postTokenBalances") or [])}
        for ix in m["instructions"]:
            if keys[ix["programIdIndex"]] != LH: continue
            d = base58.b58decode(ix["data"])
            for a in ix["accounts"]:
                own = toks.get(a)
                tag = "token acct of the signer" if own == signer else ("token acct of ANOTHER wallet" if own else "not a token acct (or absent)")
                kinds[(d[0], tag)] += 1
                if own and own != signer and len(ex) < 5: ex.append((signer[:8], own[:8], d.hex()[:40]))
        seen[signer[:8]] += 1
print("pump txs with Lighthouse sampled:", n, "signers", len(seen))
for k, v in kinds.most_common(12): print("  ", k, v)
print("examples (signer, owner of the asserted token account, data):", ex)
