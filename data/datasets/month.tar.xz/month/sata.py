import sys, json, collections, time
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/rivalpnl")
import common as C, pumpparse as PP
C.MIN_GAP = 0.3
P = "satasbJpbrKfuJzdZzVDb5hyCoGiDuZYoArSG7qfHdw"; W = "6anjqMeWigQFo5wpciARAunVQUXTqoat8w8fFWarCkpc"
# 1) who signs satasbJp transactions? (newest 2000 signatures, signer of a sample)
r = C.rpc("getTransactionsForAddress", [P, {"transactionDetails": "signatures", "sortOrder": "desc", "limit": 1000}], cache=False) or {}
d = r.get("data") or []
signers = collections.Counter()
for t in d[::20]:
    tx = C.rpc("getTransaction", [t["signature"], {"encoding": "json", "maxSupportedTransactionVersion": 1}])
    if tx: signers[tx["transaction"]["message"]["accountKeys"][0]] += 1
span = (max(x.get("blockTime") or 0 for x in d) - min(x.get("blockTime") or 0 for x in d)) / 60 if d else 0
print(f"satasbJp: {len(d)} txs in the last {span:.0f} min; sampled signers: {[(k[:8], v) for k, v in signers.most_common(10)]}")
# 2) one of each kind from his month rows, fully: every account's SOL change
rows = [json.loads(l) for l in open(f"{SP}/month/6anjqMeW.jsonl")]
pick = {}
for r0 in rows:
    k = None
    if any(t[1] == W for t in r0["tr"]) and any(t[1] == W and t[2] and t[3] == 0 for t in r0["tr"]): k = "zero buy"
    elif any(t[1] == W and t[2] and t[3] > 0 for t in r0["tr"]): k = "real buy"
    elif any(t[1] == W and not t[2] and t[3] > 0 for t in r0["tr"]): k = "real sell"
    elif not r0["tr"] and r0["d"] > 5e9 and any(c[0] == P for c in r0["calls"]): k = "big inflow"
    if k and k not in pick and r0["bt"] > 1792500000: pick[k] = r0["sig"]
for k, sig in pick.items():
    tx = C.rpc("getTransaction", [sig, {"encoding": "json", "maxSupportedTransactionVersion": 1}])
    ks = PP.keys_of(tx); pre, post = tx["meta"]["preBalances"], tx["meta"]["postBalances"]
    ch = [(ks[i], (post[i] - pre[i]) / 1e9) for i in range(len(pre)) if post[i] != pre[i]]
    sata_ix = [ix for ix in tx["transaction"]["message"]["instructions"] if ks[ix["programIdIndex"]] == P]
    accs = [ks[a] for a in sata_ix[0]["accounts"]] if sata_ix else []
    print(f"\n{k}: {sig[:16]} {time.strftime('%m-%d %H:%M:%S', time.gmtime(tx['blockTime']))}")
    print("  SOL changes:", [(a[:8], round(v, 4)) for a, v in ch])
    print("  satasbJp accounts:", [a[:8] for a in accs][:18])
    logs = [l for l in (tx["meta"].get("logMessages") or []) if "satasb" in l or "Program log" in l][:6]
    print("  logs:", [l[:90] for l in logs])
