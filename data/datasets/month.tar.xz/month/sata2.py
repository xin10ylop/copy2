import sys, json, collections, time
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month"); sys.path.insert(0, SP + "/rivalpnl")
import pub, pumpparse as PP
P = "satasbJpbrKfuJzdZzVDb5hyCoGiDuZYoArSG7qfHdw"; W = "6anjqMeWigQFo5wpciARAunVQUXTqoat8w8fFWarCkpc"
sigs = pub.rpc("getSignaturesForAddress", [P, {"limit": 200}], cache=False) or []
span = (sigs[0]["blockTime"] - sigs[-1]["blockTime"]) / 60 if sigs else 0
signers = collections.Counter()
for s in sigs[::10]:
    t = pub.tx(s["signature"])
    if t: signers[t["transaction"]["message"]["accountKeys"][0]] += 1
print(f"satasbJp: last {len(sigs)} txs span {span:.0f} min; sampled signers: {[(k[:8], v) for k, v in signers.most_common(8)]}")
rows = [json.loads(l) for l in open(f"{SP}/month/6anjqMeW.jsonl")]
pick = {}
for r0 in rows:
    if r0["bt"] < 1792700000: continue
    k = None
    mine = [t for t in r0["tr"] if t[1] == W]
    if mine and mine[0][2] and mine[0][3] == 0: k = "zero buy"
    elif mine and mine[0][2] and mine[0][3] > 0: k = "real buy"
    elif mine and not mine[0][2] and mine[0][3] > 0: k = "real sell"
    elif not r0["tr"] and r0["d"] > 5e9 and any(c[0] == P for c in r0["calls"]): k = "big inflow"
    if k and k not in pick: pick[k] = r0["sig"]
for k, sig in pick.items():
    t = pub.tx(sig)
    if not t: print(k, "not found"); continue
    ks = PP.keys_of(t); pre, post = t["meta"]["preBalances"], t["meta"]["postBalances"]
    ch = [(ks[i], (post[i] - pre[i]) / 1e9) for i in range(len(pre)) if post[i] != pre[i]]
    six = [ix for ix in t["transaction"]["message"]["instructions"] if ks[ix["programIdIndex"]] == P]
    accs = [ks[a] for a in six[0]["accounts"]] if six else []
    tok = [(b["owner"][:8], b["mint"][:8], b["uiTokenAmount"]["uiAmountString"]) for b in (t["meta"].get("postTokenBalances") or [])][:6]
    print(f"\n{k}: {time.strftime('%m-%d %H:%M:%S', time.gmtime(t['blockTime']))} {sig[:12]}")
    print("  SOL changes:", [(a[:8], round(v, 4)) for a, v in ch])
    print("  satasbJp accounts:", [a[:8] for a in accs][:20])
    print("  token balances after (owner, mint, amount):", tok)
    print("  logs:", [l[:100] for l in (t["meta"].get("logMessages") or []) if "Program log" in l][:6])
