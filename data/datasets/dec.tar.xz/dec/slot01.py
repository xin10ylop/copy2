# Every transaction that touches the mint in its first slots (failed ones too), in block order, with programs and
# what it did; for a dumped coin and a normal coin of the same operator.
import sys, json, glob
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month"); sys.path.insert(0, SP + "/rivalpnl"); sys.path.insert(0, "/home/user/rugsnipe/analysis")
import tri, pumpparse as PP, common as C
from rugsnipe_analysis import events as E
A = "AHwJSnFNUiAU9FfT5ewW2osqMo938WtL7KhfsJyfpaN2"
cr = {}
for f in glob.glob(SP + "/univ/creates_*.json"):
    for c in json.load(open(f)): cr[c["mint"]] = c
BW = json.load(open(SP + "/dec/bwall.json"))
def show(prefix, span=2):
    m = next(k for k in cr if k.startswith(prefix)); c = cr[m]
    print(f"\n== {m[:8]} create slot {c['slot']} idx {c['idx']} signer {c['signer'][:8]} uri {c['uri']} bundle {[w[:6] for w in BW.get(m, {}).get('bw', [])]}")
    allsig = []; before = None
    for page in range(50):
        o = {"limit": 1000}
        if before: o["before"] = before
        s = tri.rpc("getSignaturesForAddress", [m, o], cache=True) or []
        allsig += s
        if len(s) < 1000: break
        before = s[-1]["signature"]
    sel = [x for x in allsig if x["slot"] <= c["slot"] + span]
    rows = []
    for x in sel:
        t = tri.tx(x["signature"])
        if not t: continue
        ks = PP.keys_of(t); a = PP.analyze(t)
        evs = []
        for prog, accs, data, parsed, oi, inner in PP._ixs(t, ks):
            if prog == C.PUMP and data[:8] == E.EVENT_IX_TAG and data[8:16] == E.DISC_TRADE:
                try:
                    e = E.decode_trade(data[8:])
                    if e.mint == m: evs.append(("B" if e.is_buy else "S") + f"{e.sol_amount/1e9:.2f}")
                except Exception: pass
        # token transfers of the mint (pre/post token balances)
        tb = {}
        for b in (t["meta"].get("preTokenBalances") or []):
            if b["mint"] == m: tb[b["owner"]] = [float(b["uiTokenAmount"]["uiAmount"] or 0), None]
        for b in (t["meta"].get("postTokenBalances") or []):
            if b["mint"] == m: tb.setdefault(b["owner"], [0.0, None])[1] = float(b["uiTokenAmount"]["uiAmount"] or 0)
        moves = {o[:6]: round((v[1] or 0) - (v[0] or 0)) for o, v in tb.items() if abs((v[1] or 0) - (v[0] or 0)) > 1}
        rows.append((t["slot"] - c["slot"], t.get("transactionIndex"), ks[0][:6], "ERR" if t["meta"].get("err") else "ok", a["pump_ix"], evs, a["tip_total"], moves))
    for r in sorted(rows, key=lambda r: (r[0], r[1] or 0)):
        who = "HIM" if r[2] == A[:6] else ""
        print(f"   +{r[0]} idx {str(r[1]):>4s} {r[2]} {r[3]:3s} {str(r[4])[:40]:40s} {str(r[5])[:30]:30s} tip {r[6]} tok {str(r[7])[:70]} {who}")
for p in ("2XjwMxzb", "53NMCdLh", "DXQyQYk8", "44izpdXG"):
    show(p)
