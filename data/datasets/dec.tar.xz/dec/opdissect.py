# Dissect the operators of last night: every coin each bundle-wallet set bought (Oct 24 12:00 - Oct 25 09:13), his action
# and P&L on it, and the coin's own first 12 slots. -> dec/night/ops.json, tapes in dec/night/coins/ (12 slots).
import sys, json, os, time, collections
from concurrent.futures import ThreadPoolExecutor
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
src = open(SP + "/dec/night.py").read()
exec(src.split("# 1. his attempts")[0])
exec("def decode" + src.split("def decode")[1].split("def coin(m):")[0])
WB = json.load(open(OUT + "/wbuys.json"))
# 1. his trades per mint, from his transactions (cached)
ss, _ = sigs_range(A, TW, T1 + 3600, 100)
him = collections.defaultdict(lambda: dict(att=0, failed=0, spent=0, got=0, buy_slot=None, sell_slot=None, buys=[]))
for x in ss:
    t = tri.tx(x["signature"])
    if not t: continue
    ks = PP.keys_of(t)
    if ks[0] != A: continue
    fail = (t.get("meta") or {}).get("err") is not None
    m = None; buy = sell = False
    for prog, accs, data, parsed, oi, inner in PP._ixs(t, ks):
        if prog == C.PUMP and not inner and data[:8] in PP.IXR:
            n = PP.IXR[data[:8]]
            if n.startswith("buy"): buy = True; m = accs[2] if len(accs) > 2 else m
            if n.startswith("sell"): sell = True; m = accs[2] if len(accs) > 2 else m
    if not m: continue
    h = him[m]
    if buy:
        h["att"] += 1; h["failed"] += fail
        h["buys"].append([t["slot"], t.get("transactionIndex"), fail, [c for c in []]])
        if not fail and h["buy_slot"] is None: h["buy_slot"] = t["slot"]
    for e in decode(t, m)[3]:
        if e[0] != A: continue
        if e[1]: h["spent"] += e[2] + e[6]
        else: h["got"] += e[2] - e[6]; h["sell_slot"] = t["slot"]
json.dump(him, open(OUT + "/him.json", "w"))
log("his mints", len(him))
# 2. operators: wallets that bought the same mint in the same slot are one
P = {}
def find(x):
    while P.setdefault(x, x) != x: P[x] = P[P[x]]; x = P[x]
    return x
by = collections.defaultdict(list)
for w, L in WB.items():
    for s, m, vb, sol in L: by[(m, s)].append(w)
for k, ws in by.items():
    for w in ws[1:]: P[find(ws[0])] = find(w)
ops = collections.defaultdict(dict)
for w, L in WB.items():
    o = find(w)
    for s, m, vb, sol in L:
        c = ops[o].setdefault(m, dict(slot=s, wallets=[], sizes=[], vb=vb))
        c["slot"] = min(c["slot"], s); c["wallets"].append(w); c["sizes"].append(sol); c["vb"] = min(c["vb"], vb)
big = {o: v for o, v in ops.items() if len(v) >= 8}
log("operators with 8+ coins", len(big), "coins", sum(len(v) for v in big.values()))
json.dump({o: v for o, v in big.items()}, open(OUT + "/ops.json", "w"))
# 3. 12-slot tapes for every coin of those operators
night_span = set()
def tape(m):
    p = f"{OUT}/coins/{m}.json"
    if os.path.exists(p):
        t = json.load(open(p))
        if any(r[0] > t["cs"] for r in t["rows"]) or not t["rows"]: return "have"
    bc = C.bonding_curve(m); allsig = []; before = None
    for page in range(300):
        o = {"limit": 1000}
        if before: o["before"] = before
        s = tri.rpc("getSignaturesForAddress", [bc, o], cache=False) or []
        allsig += s
        if len(s) < 1000: break
        before = s[-1]["signature"]
    if not allsig: return "empty"
    cs = min(x["slot"] for x in allsig)
    rows = []
    for x in allsig:
        if x["slot"] <= cs + 12 and x.get("err") is None:
            t = tri.tx(x["signature"])
            if t: rows.append(decode(t, m))
    rows.sort(key=lambda r: (r[0], r[1]))
    cr = next((r for r in rows if r[4]), None) or (rows[0] if rows else None); c = None
    if cr:
        evs = cr[3]; c = dict(slot=cr[0], idx=cr[1], signer=cr[2], user=evs[0][0] if evs else cr[2], creator=evs[0][7] if evs else cr[2])
    json.dump(dict(mint=m, cs=cs, reached=True, create=c, rows=[r[:4] for r in rows]), open(p + ".tmp", "w")); os.replace(p + ".tmp", p)
    return "pulled"
ms = sorted({m for v in big.values() for m in v})
cnt = collections.Counter()
def safe(m):
    try: cnt[tape(m)] += 1
    except Exception as e: cnt["error"] += 1
    if sum(cnt.values()) % 100 == 0: log("tapes", sum(cnt.values()), "of", len(ms), dict(cnt))
with ThreadPoolExecutor(8) as ex: list(ex.map(safe, ms))
log("opdissect done", dict(cnt))
