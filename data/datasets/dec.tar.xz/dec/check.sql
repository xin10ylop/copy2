
create temp table tiers(m8 text, tier int);
insert into tiers values ('',-1);
create temp table tweets(m8 text, kind text, ms int, slot_off int);
insert into tweets values ('','',0,0);
create temp table feeds(m8 text, call text);
insert into feeds values ('','');
create temp table dumps(m8 text, act text, host text);
insert into dumps values ('','','');
create temp table follows(m8 text, yes text, kind text, host text, act text);
insert into follows values ('AbCdEfGh','yes','rule','meta.uxento.io','fire'),('StUvWxYz','yes','skip_uri_host','gg.sc','log');
create temp view pos0 as
  select p.mint, p.cost, p.state, p.opened_slot, p.closed_slot, min(s.sent_unix_ms) t_ms, max(s.bid) bid,
         coalesce((select sum(e.sol_delta) from exits e where e.mint = p.mint), 0) ex,
         (select group_concat(distinct e.reason) from exits e where e.mint = p.mint) reason,
         coalesce((select max(t.tier) from tiers t where t.m8 = substr(p.mint, 1, 8)), 0) tier,
         -- the execution the position's P&L leaves out: the filled buy's fee + tip, each filled sell's priority + tip + base fee
         coalesce((select sum(coalesce(f.fee, 0) + coalesce(f.tip, 0)) from fills f
                   where f.intent_id = p.intent_id and f.fail_reason is null), 0)
         + coalesce((select sum(coalesce(x.prio, 0) + coalesce(x.tip, 0) + 5000) from exits e join sends x on x.sig = e.sig
                     where e.mint = p.mint), 0) txc
  from positions p join sends s on s.intent_id = p.intent_id
  group by p.mint;
create temp view pos as select *, ex - cost - txc net from pos0;
create temp view races as
  select f.sig, f.fail_reason, coalesce(f.fail_cost, f.fee, 0) fail_cost, s.sent_unix_ms t_ms
  from fills f join sends s on s.sig = f.sig;
with scopes(scope, ms) as (values ('process', 1792886400 * 1000), ('today', 1792886400 * 1000))
select sc.scope,
  (select count(*) from races r where r.t_ms >= sc.ms) races,
  (select coalesce(sum(r.fail_reason is null), 0) from races r where r.t_ms >= sc.ms) landed,
  (select round(100.0 * coalesce(sum(r.fail_reason is null), 0) / max(count(*), 1), 0) from races r where r.t_ms >= sc.ms) land_pct,
  (select count(*) from pos where state = 'closed' and t_ms >= sc.ms) closed,
  (select coalesce(sum(net > 0), 0) from pos where state = 'closed' and t_ms >= sc.ms) wins,
  (select round(100.0 * avg(net * 1.0 / cost), 1) from pos where state = 'closed' and cost > 0 and t_ms >= sc.ms) mean_pct,
  (select round(coalesce(sum(ex - cost), 0) / 1e9, 4) from pos where state = 'closed' and t_ms >= sc.ms) curve_sol,
  (select round(-coalesce(sum(txc), 0) / 1e9, 4) from pos where state = 'closed' and t_ms >= sc.ms) tips_fees,
  (select round(-coalesce(sum(r.fail_cost), 0) / 1e9, 4) from races r where r.fail_reason is not null and r.t_ms >= sc.ms) failed_sol,
  (select round((coalesce((select sum(net) from pos where state = 'closed' and t_ms >= sc.ms), 0)
                - coalesce((select sum(r.fail_cost) from races r where r.fail_reason is not null and r.t_ms >= sc.ms), 0)) / 1e9, 4)) net_sol
from scopes sc;
.print
.print == buy bid since the A/B started (bid.ab_by_tier: the mints whose first byte is odd bid the second arm, the rest bid.by_tier)
select round(b.bid / 1e6, 2) bid_m, b.attempts, coalesce(l.landed, 0) landed,
       round(100.0 * coalesce(l.landed, 0) / max(b.attempts, 1), 0) land_pct, coalesce(l.closed, 0) closed,
       coalesce(l.mean_pct, '-') mean_pct, coalesce(l.net_sol, 0.0) net_sol
from (select s.bid, count(distinct s.intent_id) attempts from sends s
      where s.kind = 'buy' and s.sent_unix_ms >= 1792886400 * 1000 group by s.bid) b
left join (select bid, count(*) landed, sum(state = 'closed') closed,
                  round(100.0 * avg(case when state = 'closed' and cost > 0 then net * 1.0 / cost end), 1) mean_pct,
                  round(sum(case when state = 'closed' then net else 0 end) / 1e9, 4) net_sol
           from pos where t_ms >= 1792886400 * 1000 group by bid) l on l.bid = b.bid
order by b.bid;
.print
.print == buy routes today (won = our buy landed through it, lost = it landed and failed; a bundle never lands failed)
select s.sender route, count(*) sent, coalesce(sum(s.result = 'accepted'), 0) accepted,
       coalesce(sum(f.sig is not null and f.fail_reason is null), 0) won,
       coalesce(sum(f.sig is not null and f.fail_reason is not null), 0) lost,
       round(coalesce(sum(case when f.sig is null then 0 when f.fail_reason is null then coalesce(f.fee, 0) + coalesce(f.tip, 0)
                               else coalesce(f.fail_cost, f.fee, 0) end), 0) / 1e9, 4) paid_sol,
       coalesce(group_concat(distinct nullif(s.err, '')), '-') errors
from sends s left join fills f on f.sig = s.sig
where s.kind = 'buy' and s.sent_unix_ms >= 1792886400 * 1000
group by s.sender order by won desc, sent desc;
.print
.print == by tier since the era started (Oct 25 03:46 UTC) (closed trades, after tips and fees)
select tier, count(*) trades, sum(net > 0) wins, round(100.0 * avg(net * 1.0 / cost), 1) mean_pct,
       round(sum(net) / 1e9, 4) net_sol, round(avg(cost) / 1e9, 3) avg_stake
from pos where state = 'closed' and cost > 0 and t_ms >= 1792900000 * 1000 group by tier order by tier;
.print
.print == tweet check since the era started (Oct 25 03:46 UTC) (entry.tweet_gate): verdicts by kind, how fast they came, and our closed trades by verdict since the rule started
with k as (select kind, ms, slot_off, row_number() over (partition by kind order by ms) rn,
                  count(*) over (partition by kind) n from tweets where m8 <> '')
select kind verdict, max(n) creates, sum(slot_off = 0) in_create_slot, sum(slot_off = 1) next_slot, sum(slot_off >= 2) later,
       max(case when rn = (n + 1) / 2 then ms end) median_ms
from k group by kind order by creates desc;
select coalesce((select t.kind from tweets t where t.m8 = substr(p.mint, 1, 8) limit 1), 'not fetched') verdict,
       count(*) trades, sum(net > 0) wins, round(100.0 * avg(net * 1.0 / cost), 1) mean_pct, round(sum(net) / 1e9, 4) net_sol
from pos p where state = 'closed' and cost > 0 and t_ms >= 1792886400 * 1000 group by verdict order by trades desc;
.print
.print == tweet feed since the era started (Oct 25 03:46 UTC) (entry.tweet_feed): its calls against the tweet check's verdict on the same coin, and our closed trades by call
select f.call, count(*) creates, coalesce(sum(t.kind = 'first'), 0) first, coalesce(sum(t.kind = 'copy'), 0) copy,
       coalesce(sum(t.kind = 'stale'), 0) stale, coalesce(sum(t.kind = 'no_tweet'), 0) no_tweet,
       coalesce(sum(t.kind = 'error'), 0) error, sum(t.kind is null) no_verdict
from feeds f left join tweets t on t.m8 = f.m8 where f.m8 <> '' group by f.call order by creates desc;
select coalesce((select f.call from feeds f where f.m8 = substr(p.mint, 1, 8) limit 1), 'not called') call,
       count(*) trades, sum(net > 0) wins, round(100.0 * avg(net * 1.0 / cost), 1) mean_pct, round(sum(net) / 1e9, 4) net_sol
from pos p where state = 'closed' and cost > 0 and t_ms >= 1792886400 * 1000 group by call order by trades desc;
.print
.print == dumper list since the era started (Oct 25 03:46 UTC) (entry.dumper_skip): hits by uri host, and our closed trades since the rule started by the hit's host (big = -30% or worse)
select host, count(*) hits, sum(act = 'skipped') skipped, sum(act = 'logged') fired_anyway
from dumps where m8 <> '' group by host order by hits desc;
select coalesce((select d.host from dumps d where d.m8 = substr(p.mint, 1, 8) limit 1), 'no hit') dumper_host,
       count(*) trades, sum(net > 0) wins, sum(net <= -0.3 * cost) big, round(100.0 * avg(net * 1.0 / cost), 1) mean_pct,
       round(sum(net) / 1e9, 4) net_sol
from pos p where state = 'closed' and cost > 0 and t_ms >= 1792886400 * 1000 group by dumper_host order by trades desc;
.print
.print == follow since the era started (Oct 25 03:46 UTC) (entry.follow, docs/16): verdicts at the fire (rule = our rule's coin; skip_* = a coin our rule skips,
.print    parked for its verdict: log = followed but not bought in log mode), and our closed trades by the verdict
select kind, yes followed, count(*) coins, sum(act = 'fire') fired, sum(act = 'skip') skipped, sum(act = 'log') logged
from follows where m8 <> '' group by kind, yes order by kind = 'rule' desc, coins desc;
select coalesce((select f.yes || ' ' || f.kind from follows f where f.m8 = substr(p.mint, 1, 8) limit 1), 'no verdict') follow,
       count(*) trades, sum(net > 0) wins, sum(net <= -0.3 * cost) big, round(100.0 * avg(net * 1.0 / cost), 1) mean_pct,
       round(sum(net) / 1e9, 4) net_sol
from pos p where state = 'closed' and cost > 0 and t_ms >= 1792900000 * 1000 group by follow order by trades desc;
.print
.print == last 10 trades, newest first (pct and net_sol after tips and fees)
select strftime('%H:%M:%S', t_ms / 1000, 'unixepoch') time, substr(mint, 1, 8) mint, tier, round(cost / 1e9, 3) stake,
       case when state = 'closed' then round(100.0 * net / max(cost, 1), 1) end pct,
       case when state = 'closed' then round(net / 1e9, 4) end net_sol, round(txc / 1e9, 4) tips_fees, state,
       coalesce(reason, '-') exit, case when closed_slot is not null then closed_slot - opened_slot end held_slots
from pos where t_ms >= 1792900000 * 1000 order by t_ms desc limit 10;
.print
.print == open now
select count(*) open_now, coalesce(group_concat(substr(p.mint, 1, 8) || ' tier '
         || coalesce((select max(t.tier) from tiers t where t.m8 = substr(p.mint, 1, 8)), 0), ', '), '-') positions
from positions p where p.state <> 'closed';
.print
.print == risk ledger today
select day, round(realized / 1e9, 4) realized_sol, buys, killed, coalesce(kill_reason, '-') kill_reason
from risk where day = date('now');

