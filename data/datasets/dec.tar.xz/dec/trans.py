# Oct 23 - Oct 24 12:00: within the operators he follows, does his take of a coin depend on what happened on the
# operator's previous coin (his result, the template)? Operators = bundle-wallet clusters (ops.py).
import json, collections, glob, os
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
BW = json.load(open(SP + "/dec/bwall.json"))
cr = {}
for f in glob.glob(SP + "/univ/creates_*.json"):
    for c in json.load(open(f)): cr[c["mint"]] = c
D = {}
for day in (23, 24):
    for r in json.load(open(SP + f"/pm/dataset_{day}.json")): D[r["mint"]] = r
T = {t["mint"]: t for t in json.load(open(SP + "/month/AHwJ_T.json"))}
P = {}
def find(x):
    while P.setdefault(x, x) != x: P[x] = P[P[x]]; x = P[x]
    return x
fan = collections.Counter(w for x in BW.values() for w in x["bw"])
for m, x in BW.items():
    ws = [w for w in x["bw"] if fan[w] <= 400]
    for w in ws[1:]: P[find(ws[0])] = find(w)
op = collections.defaultdict(list)
for m, x in BW.items():
    ws = [w for w in x["bw"] if fan[w] <= 400]
    if ws and m in D and m in cr: op[find(ws[0])].append(m)
seqs = {o: sorted(ms, key=lambda m: (cr[m]["slot"], cr[m]["idx"] or 0)) for o, ms in op.items() if len(ms) >= 8}
fol = {o: s for o, s in seqs.items() if sum(D[m]["he"] for m in s) / len(s) >= 0.5}
print("operators with 8+ coins", len(seqs), "| followed (he took >= 50%)", len(fol), "| their coins", sum(len(s) for s in fol.values()), "taken", sum(D[m]["he"] for s in fol.values() for m in s))
def tmpl(m): return (round(D[m]["dev"], 2), D[m]["host"])
stat = collections.defaultdict(lambda: [0, 0])
for o, s in fol.items():
    for k in range(1, len(s)):
        p, m = s[k - 1], s[k]
        tp = T.get(p)
        prev = "prev skipped" if not D[p]["he"] else ("prev: he lost" if tp and tp["pnl"] < 0 else "prev: he won" if tp and tp["pnl"] >= 0 else "prev: attempted, no fill")
        stat[prev][0] += 1; stat[prev][1] += D[m]["he"]
        ch = "template same" if tmpl(p) == tmpl(m) else "template changed"
        stat[ch][0] += 1; stat[ch][1] += D[m]["he"]
        gap = (cr[m]["bt"] - cr[p]["bt"]); g = "gap < 2 min" if gap < 120 else "gap 2-10 min" if gap < 600 else "gap > 10 min"
        stat[g][0] += 1; stat[g][1] += D[m]["he"]
for k in sorted(stat):
    n, h = stat[k]; print(f"   {k:28s} next coins {n:5d}  he took {100*h/n:5.1f}%")
json.dump({o: s for o, s in fol.items()}, open(SP + "/dec/fol_ops_2324.json", "w"))
