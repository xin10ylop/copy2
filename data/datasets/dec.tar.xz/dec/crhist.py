# The creator-fee wallets of the followed operators' coins: did the wallet exist before the create (transactions), who
# funded it, and his take by that.
import sys, json, glob, collections, os
from concurrent.futures import ThreadPoolExecutor
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month"); sys.path.insert(0, SP + "/rivalpnl"); sys.path.insert(0, "/home/user/rugsnipe/analysis")
import tri, pumpparse as PP, common as C
tri.MIN_GAP = 0.02
fol = json.load(open(SP + "/dec/fol_ops_2324.json"))
cr = {}
for f in glob.glob(SP + "/univ/creates_*.json"):
    for c in json.load(open(f)): cr[c["mint"]] = c
D = {}
for day in (23, 24):
    for r in json.load(open(SP + f"/pm/dataset_{day}.json")): D[r["mint"]] = r
todo = []
for o, s in fol.items():
    rate = sum(D[m]["he"] for m in s) / len(s)
    main = collections.Counter(cr[m]["creator"] for m in s).most_common(1)[0][0]
    for m in s:
        c = cr[m]
        if c["creator"] != main and c["creator"] != c["signer"]: todo.append((m, c["creator"], c["bt"], o, rate))
def one(x):
    m, w, bt, o, rate = x
    s = tri.rpc("getSignaturesForAddress", [w, {"limit": 100}], cache=True) or []
    before = [y for y in s if (y.get("blockTime") or 0) < bt]
    after = [y for y in s if (y.get("blockTime") or 0) >= bt]
    fund = None
    if before:
        t = tri.tx(before[-1]["signature"])
        if t:
            ks = PP.keys_of(t); fund = ks[0]
    return dict(m=m, w=w, o=o, rate=rate, n_before=len(before), n_after=len(after), first_signer=fund, first_dt=(bt - (before[-1].get("blockTime") or bt)) if before else None)
with ThreadPoolExecutor(8) as ex: R = list(ex.map(one, todo))
json.dump(R, open(SP + "/dec/crhist.json", "w"))
st = collections.defaultdict(lambda: [0, 0])
for r in R:
    he = D[r["m"]]["he"]; kind = "half" if r["rate"] <= 0.85 else "near"
    k = (kind, "no tx before the create" if not r["n_before"] else ("funded by the signer/operator" if r["first_signer"] == cr[r["m"]]["signer"] else "had txs before (other funder)"))
    st[k][0] += 1; st[k][1] += he
    k2 = (kind, "has txs after (fee claims?)" if r["n_after"] else "nothing after")
    st[k2][0] += 1; st[k2][1] += he
for k in sorted(st): n, h = st[k]; print(f"   {k[0]:4s} {k[1]:36s} coins {n:4d} he took {100*h/n:5.1f}%")
