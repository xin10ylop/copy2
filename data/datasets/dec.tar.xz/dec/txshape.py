# His take within the followed operators by the create transaction's shape (tip and its route, account count, lookup
# table, compute price, instructions, the uri form).
import sys, json, glob, collections, re
from concurrent.futures import ThreadPoolExecutor
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month"); sys.path.insert(0, SP + "/rivalpnl"); sys.path.insert(0, "/home/user/rugsnipe/analysis")
import tri, pumpparse as PP, common as C
tri.MIN_GAP = 0.02
fol = json.load(open(SP + "/dec/fol_ops_2324.json"))
cr = {}
for f in glob.glob(SP + "/univ/creates_*.json"):
    for c in json.load(open(f)): cr[c["mint"]] = c
D = {}
for day in (23, 24):
    for r in json.load(open(SP + f"/pm/dataset_{day}.json")): D[r["mint"]] = r
ms = [m for o, s in fol.items() for m in s]
def shape(m):
    c = cr[m]; t = tri.tx(c["sig"])
    if not t: return m, None
    ks = PP.keys_of(t); a = PP.analyze(t); msg = t["transaction"]["message"]
    la = (t["meta"].get("loadedAddresses") or {})
    uri = c["uri"]; uid = uri.rsplit("/", 1)[-1].split(".")[0]
    return m, dict(tip=("tip " + "+".join(sorted(a["tips"]))) if a["tip_total"] else "no tip", keys=len(ks), alt=bool(la.get("writable") or la.get("readonly")),
                   cup=a["cu_price"], nix=len(msg["instructions"]), sysix=sum(1 for ix in msg["instructions"] if ks[ix["programIdIndex"]].startswith("1111111")),
                   uid=("hex" if re.fullmatch(r"[0-9a-f]+", uid) else "b62") + str(len(uid)), ver=t.get("version"))
with ThreadPoolExecutor(8) as ex: S = dict(ex.map(shape, ms))
json.dump(S, open(SP + "/dec/createshape_2324.json", "w"))
for feat in ("tip", "keys", "alt", "cup", "nix", "sysix", "uid", "ver"):
    st = collections.defaultdict(lambda: [0, 0])
    for o, s in fol.items():
        rate = sum(D[m]["he"] for m in s) / len(s)
        for m in s:
            if not S.get(m): continue
            k = (("half-taken op" if rate <= 0.85 else "near-all op"), S[m][feat]); st[k][0] += 1; st[k][1] += D[m]["he"]
    print(feat, {f"{k[0][:4]}:{k[1]}": f"{h}/{n} {100*h/n:.0f}%" for k, (n, h) in sorted(st.items(), key=lambda kv: str(kv[0])) if n >= 5})
