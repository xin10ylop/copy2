# Every coin he BOUGHT today (landed buy), his wallet-true net, what we did on it, and the coin as our gates see it.
import sys, json, os, datetime, collections
from concurrent.futures import ThreadPoolExecutor
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
OUT = SP + "/dec/live2/day"
A = "AHwJSnFNUiAU9FfT5ewW2osqMo938WtL7KhfsJyfpaN2"; US = "4g49xGbgHZk3QYR1o6QSfDUbHmJZFwN6iDp6Vco1skff"
src = open(SP + "/dec/live2/coins.py").read().split("mints = sorted(")[0]
g = {}; exec(src, g)
U = lambda x: datetime.datetime.fromtimestamp(x, datetime.timezone.utc).strftime("%H:%M")
def W(a): return json.load(open(f"{OUT}/walk_{a[:6]}.json"))["rows"]
def per(rows):
    d = collections.defaultdict(lambda: dict(buys=0, ok=0, net=0, bt=None, sol=0))
    for r in rows:
        x = d[r["m"]]; x["net"] += r["delta"]
        if r["kind"] == "buy":
            x["buys"] += 1; x["ok"] += r["ok"]; x["bt"] = min(x["bt"] or r["bt"], r["bt"])
            if r["ok"] and r["fill"]: x["sol"] += r["fill"][0]
    return d
H, O = per(W(A)), per(W(US))
land = {m: h for m, h in H.items() if h["ok"]}
cache = json.load(open(SP + "/dec/live2/coins.json"))
need = [m for m in land if not cache.get(m)]
def safe(m):
    try: return g["coin"](m)
    except Exception as e: return None
with ThreadPoolExecutor(8) as ex: cache.update(dict(zip(need, ex.map(safe, need))))
json.dump(cache, open(SP + "/dec/live2/coins.json", "w"))
# the hosts our own rule fired on today (before the follow went on at 14:50: rule coins only)
ours_hosts = collections.Counter((cache.get(m) or {}).get("uri_host") for m, o in O.items() if o["buys"] and (o["bt"] or 0) < 1792939859)
print("hosts of the coins our bot sent on before 14:50 (rule only):", [(h, n) for h, n in ours_hosts.most_common(8) if (cache.get(h) is None)])
TOOL = {h for h, n in ours_hosts.items() if h and n >= 3}
rows = []
for m, h in land.items():
    i = cache.get(m) or {}; o = O.get(m)
    st = "we landed" if o and o["ok"] else "we sent, lost the race" if o and o["buys"] else "we never sent"
    host = i.get("uri_host"); pb = i.get("pb"); dev = i.get("dev_buy") or 0
    feats = []
    if not i.get("bw"): feats.append("no bundle")
    if pb and pb > 40: feats.append("pb>40")
    if host not in TOOL: feats.append("host not ours")
    feats.append("followed" if i.get("followed") else "not followed")
    rows.append(dict(m=m, bt=h["bt"], net=h["net"] / 1e9, stake=h["sol"] / 1e9, st=st, host=host, pb=pb, dev=dev, feats=feats, fol=bool(i.get("followed")), bw=len(i.get("bw") or [])))
tot = sum(r["net"] for r in rows)
print(f"\nhis bought coins today {len(rows)}, his net {tot:+.3f} SOL")
by = collections.defaultdict(lambda: [0, 0.0])
for r in rows: by[r["st"]][0] += 1; by[r["st"]][1] += r["net"]
for k, (n, s) in sorted(by.items(), key=lambda kv: -kv[1][1]): print(f"   {k:24s} coins {n:4d}  his net {s:+.3f} SOL ({100*s/tot:4.0f}%)")
print("\nthe coins we never sent, by what our gates see:")
by = collections.defaultdict(lambda: [0, 0.0, 0])
for r in rows:
    if r["st"] != "we never sent": continue
    k = ("followed" if r["fol"] else "not followed", "pb>40" if (r["pb"] or 0) > 40 else ("no bundle" if not r["bw"] else "pb<=40"), "our hosts" if r["host"] in TOOL else "other host")
    by[k][0] += 1; by[k][1] += r["net"]; by[k][2] += r["net"] > 0
for k, (n, s, w) in sorted(by.items(), key=lambda kv: -kv[1][1]): print(f"   {k[0]:13s} {k[1]:9s} {k[2]:10s} coins {n:4d} wins {w:3d}  his net {s:+.3f} SOL ({100*s/tot:4.0f}%)")
print("\nthe biggest of them (his net):")
for r in sorted([r for r in rows if r["st"] == "we never sent"], key=lambda r: -abs(r["net"]))[:25]:
    print(f"   {U(r['bt'])} {r['m'][:8]} {r['net']:+.3f} stake {r['stake']:.2f} host {str(r['host'])[:22]:22} dev {r['dev']:5.2f} bw {r['bw']} pb {r['pb']} {'followed' if r['fol'] else 'not followed'}")
json.dump(rows, open(SP + "/dec/live2/day_his.json", "w"))
open(SP + "/dec/live2/his_landed_not_sent.txt", "w").write("\n".join(r["m"] for r in sorted(rows, key=lambda r: r["bt"]) if r["st"] == "we never sent") + "\n")
