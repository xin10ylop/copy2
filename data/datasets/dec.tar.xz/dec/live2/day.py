# Today from chain: every buy we and he sent (landed / failed, error), wallet-true net per mint, and each attempted coin's
# tape: price right after its bundle (p0), at create + 3 and + 10, our and his fill price.
import sys, json, os, time, datetime, threading, collections
from concurrent.futures import ThreadPoolExecutor
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month"); sys.path.insert(0, SP + "/rivalpnl"); sys.path.insert(0, "/home/user/rugsnipe/analysis")
import tri, pumpparse as PP, common as C
from rugsnipe_analysis import events as E
tri.MIN_GAP = 0.012
A = "AHwJSnFNUiAU9FfT5ewW2osqMo938WtL7KhfsJyfpaN2"; US = "4g49xGbgHZk3QYR1o6QSfDUbHmJZFwN6iDp6Vco1skff"
WSOL = "So11111111111111111111111111111111111111112"
T0 = int(datetime.datetime(2026, 10, 25, 0, 0, tzinfo=datetime.timezone.utc).timestamp()); T1 = int(time.time()) - 60
OUT = SP + "/dec/live2/day"; os.makedirs(OUT + "/tape", exist_ok=True)
def log(*a): print(time.strftime("%H:%M:%S"), *a, flush=True)
def sigs(addr, lo, hi, pages=60):
    out = []; before = None
    for _ in range(pages):
        o = {"limit": 1000}
        if before: o["before"] = before
        s = tri.rpc("getSignaturesForAddress", [addr, o], cache=False) or []
        out += [x for x in s if lo <= (x.get("blockTime") or 0) < hi]
        if len(s) < 1000 or (s[-1].get("blockTime") or 0) < lo: break
        before = s[-1]["signature"]
    return out
def walk(addr):
    P = f"{OUT}/walk_{addr[:6]}.json"
    if os.path.exists(P) and json.load(open(P))["T1"] == T1: return json.load(open(P))["rows"]
    ss = sigs(addr, T0, T1); log(addr[:6], "signatures", len(ss))
    rows = []; lock = threading.Lock()
    def one(x):
        t = tri.tx(x["signature"])
        if not t: return
        ks = PP.keys_of(t)
        if ks[0] != addr: return
        meta = t.get("meta") or {}; err = meta.get("err")
        kind = None; m = None
        for prog, accs, data, parsed, oi, inner in PP._ixs(t, ks):
            if prog == C.PUMP and not inner and data and data[:8] in PP.IXR:
                n = PP.IXR[data[:8]]
                if n.startswith("buy"): kind = "buy"; m = m or (accs[2] if len(accs) > 2 else None)
                elif n.startswith("sell"): kind = "sell"; m = m or (accs[2] if len(accs) > 2 else None)
        if not kind: return
        if m == WSOL or m is None:
            tb = [b["mint"] for b in (meta.get("postTokenBalances") or []) + (meta.get("preTokenBalances") or []) if b["mint"] != WSOL]
            m = tb[0] if tb else None
        if not m: return
        fill = None
        for prog, accs, data, parsed, oi, inner in PP._ixs(t, ks):
            if prog == C.PUMP and data and data[:8] == E.EVENT_IX_TAG and data[8:16] == E.DISC_TRADE:
                try: e = E.decode_trade(data[8:])
                except Exception: continue
                if e.user == addr and e.mint == m:
                    fill = [e.sol_amount, e.token_amount, e.virtual_sol_reserves, e.virtual_token_reserves]
        code = None
        if err:
            try: code = err["InstructionError"][1].get("Custom") if isinstance(err["InstructionError"][1], dict) else str(err["InstructionError"][1])
            except Exception: code = str(err)[:30]
        delta = meta["postBalances"][0] - meta["preBalances"][0]
        with lock: rows.append(dict(m=m, kind=kind, ok=err is None, code=code, slot=t["slot"], idx=t.get("transactionIndex") or 0, bt=x.get("blockTime"), delta=delta, fill=fill))
    with ThreadPoolExecutor(8) as ex: list(ex.map(one, ss))
    json.dump(dict(T1=T1, rows=rows), open(P, "w"))
    return rows
us = walk(US); him = walk(A)
log("our rows", len(us), "his rows", len(him))
def tape(m):
    p = f"{OUT}/tape/{m}.json"
    if os.path.exists(p): return json.load(open(p))
    bc = C.bonding_curve(m); allsig = []; before = None
    for _ in range(30):
        o = {"limit": 1000}
        if before: o["before"] = before
        s = tri.rpc("getSignaturesForAddress", [bc, o], cache=False) or []
        allsig += s
        if len(s) < 1000: break
        before = s[-1]["signature"]
    if not allsig: return None
    cs = min(x["slot"] for x in allsig)
    rows = []; cre = None
    for x in allsig:
        if x["slot"] > cs + 12 or x.get("err"): continue
        t = tri.tx(x["signature"])
        if not t: continue
        ks = PP.keys_of(t)
        for prog, accs, data, parsed, oi, inner in PP._ixs(t, ks):
            if prog != C.PUMP or not data: continue
            if data[:8] in PP.IXR and PP.IXR[data[:8]].startswith("create") and accs and accs[0] == m:
                cre = dict(slot=t["slot"], idx=t.get("transactionIndex") or 0, signer=ks[0])
            if data[:8] == E.EVENT_IX_TAG and data[8:16] == E.DISC_TRADE:
                try: e = E.decode_trade(data[8:])
                except Exception: continue
                if e.mint == m: rows.append([t["slot"], t.get("transactionIndex") or 0, e.user, int(e.is_buy), e.sol_amount, e.virtual_sol_reserves, e.virtual_token_reserves, e.creator])
    rows.sort(key=lambda r: (r[0], r[1]))
    d = dict(cs=cs, create=cre, rows=rows)
    json.dump(d, open(p + ".tmp", "w")); os.replace(p + ".tmp", p)
    return d
mints = sorted({r["m"] for r in us if r["kind"] == "buy"} | {r["m"] for r in him if r["kind"] == "buy"})
log("attempted mints (either)", len(mints))
cnt = collections.Counter()
def safe(m):
    try: tape(m); cnt["ok"] += 1
    except Exception as e: cnt["err"] += 1
with ThreadPoolExecutor(8) as ex: list(ex.map(safe, mints))
log("tapes", dict(cnt))
