# For his and our mints since 14:50: create (uri host, dev buy, creator routing, mode), bundle run, his/our result.
import sys, json, struct, os, datetime, collections
from concurrent.futures import ThreadPoolExecutor
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month"); sys.path.insert(0, SP + "/rivalpnl"); sys.path.insert(0, "/home/user/rugsnipe/analysis")
import tri, pumpparse as PP, common as C
from rugsnipe_analysis import events as E
tri.MIN_GAP = 0.015
A = "AHwJSnFNUiAU9FfT5ewW2osqMo938WtL7KhfsJyfpaN2"; US = "4g49xGbgHZk3QYR1o6QSfDUbHmJZFwN6iDp6Vco1skff"
D = json.load(open(SP + "/dec/live2/pair.json")); us, him = D["us"], D["him"]
U = lambda x: datetime.datetime.fromtimestamp(x, datetime.timezone.utc).strftime("%H:%M:%S")
seed = json.load(open("/home/user/rugsnipe/data/follow_seed.json"))
for k, v in json.load(open("/home/user/rugsnipe/data/follow_seed_today.json")).items():
    s = seed.setdefault(k, [0, 0, 0]); s[0] += v[0]; s[1] += v[1]
def rstr(b, o):
    n = struct.unpack_from("<I", b, o)[0]; return b[o + 4:o + 4 + n], o + 4 + n
def coin(m):
    bc = C.bonding_curve(m); allsig = []; before = None
    for _ in range(10):
        o = {"limit": 1000}
        if before: o["before"] = before
        s = tri.rpc("getSignaturesForAddress", [bc, o], cache=False) or []
        allsig += s
        if len(s) < 1000: break
        before = s[-1]["signature"]
    if not allsig: return None
    cs = min(x["slot"] for x in allsig)
    txs = [t for t in (tri.tx(x["signature"]) for x in allsig if x["slot"] <= cs + 3 and x.get("err") is None) if t]
    txs.sort(key=lambda t: (t["slot"], t.get("transactionIndex") or 0))
    out = dict(cs=cs)
    rows = []
    for t in txs:
        ks = PP.keys_of(t)
        for prog, accs, data, parsed, oi, inner in PP._ixs(t, ks):
            if prog != C.PUMP or not data: continue
            if data[:8] in PP.IXR and PP.IXR[data[:8]].startswith("create") and accs and accs[0] == m and "uri" not in out:
                o = 8; name, o = rstr(data, o); sym, o = rstr(data, o); uri, o = rstr(data, o)
                creator = C.b58e(data[o:o + 32]); tail = data[o + 32:]
                host = uri.decode(errors="replace").split("//")[-1].split("/")[0]
                out.update(uri_host=host, name=name.decode(errors="replace")[:16], signer=ks[0], creator=creator, idx=t.get("transactionIndex") or 0,
                           holder=bool(tail[-1]) if len(tail) >= 3 else None, tail=tail.hex())
            if data[:8] == E.EVENT_IX_TAG and data[8:16] == E.DISC_TRADE:
                try: e = E.decode_trade(data[8:])
                except Exception: continue
                if e.mint == m: rows.append((t["slot"], t.get("transactionIndex") or 0, e))
    if "uri_host" not in out: return out
    ci = out["idx"]; cset = {out["signer"], out["creator"]}
    dev = sum(e.sol_amount for s, i, e in rows if (s, i) == (cs, ci) and e.is_buy) / 1e9
    users = {e.user for s, i, e in rows if (s, i) == (cs, ci)}
    out["dev_fees"] = out["creator"] in cset | users
    out["dev_buy"] = round(dev, 3)
    bw = []; last = None; prev = ci
    for s, i, e in rows:
        if s != cs or i <= ci or not e.is_buy or e.user in (A, US): continue
        if i - prev <= 2 and i - ci <= 5:
            prev = i; last = e
            if e.user not in bw and e.user not in cset: bw.append(e.user)
    out["bw"] = bw; out["pb"] = round(last.virtual_sol_reserves / 1e9, 1) if last else None
    f = "dev" if out["dev_fees"] else "third"
    fol = [w for w in bw if (x := seed.get(f"{w}:{f}")) and x[1] >= 2 and x[1] >= 0.3 * x[0]]
    out["followed"] = bool(fol)
    sl = [s for s, i, e in rows if e.user == A and e.is_buy]
    out["his_slot"] = (min(sl) - cs) if sl else None
    return out
mints = sorted(set(us) | {m for m, h in him.items() if h["buys"]})
with ThreadPoolExecutor(8) as ex: info = dict(zip(mints, ex.map(lambda m: (lambda: coin(m))() if True else None, mints)))
json.dump(info, open(SP + "/dec/live2/coins.json", "w"))
print(f"{'time':8} {'mint':8} {'us':6} {'him':12} {'him_net':>7} {'host':22} {'dev':>5} {'fees':5} {'bw':>2} {'pb':>5} {'fol':3} {'hold':4} {'slot':>4}")
tot = collections.Counter()
for m in sorted(mints, key=lambda m: (us.get(m) or him.get(m))["bt"] or 0):
    i = info.get(m) or {}; h = him.get(m) or {}; u = us.get(m)
    us_s = "-" if not u else ("land" if u["buys"] > u["failed"] else "fail")
    if h.get("buys"):
        hs = "fail" if h["buys"] == h["failed"] else ("sold" if h["sells"] else "open")
        hn = (h["got"] - h["spent"]) / 1e9 if h["sells"] else 0
    else: hs, hn = "-", 0
    bt = (u or h)["bt"]
    print(f"{U(bt)} {m[:8]} {us_s:6} {hs:12} {hn:7.3f} {str(i.get('uri_host'))[:22]:22} {i.get('dev_buy', 0):5.2f} {('dev' if i.get('dev_fees') else 'third'):5} {len(i.get('bw') or []):2d} {str(i.get('pb')):>5} {('yes' if i.get('followed') else 'no'):3} {str(i.get('holder'))[:4]:4} {str(i.get('his_slot')):>4}")
    if h.get("buys") and not u: tot[("missed", i.get("uri_host"), "fol" if i.get("followed") else "nofol")] += hn
for k, v in sorted(tot.items(), key=lambda kv: -kv[1]): print(k, round(v, 4))
