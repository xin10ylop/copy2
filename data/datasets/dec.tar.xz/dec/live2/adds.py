# The follow-added coins we landed: their bundle wallets, the records' counts (seed + today), and the coins those
# wallets bundled in the night data with his take and uri host.
import sys, json, collections, os
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/dec/live2")
D = json.load(open(SP + "/dec/live2/pair.json"))
import importlib.util
spec = importlib.util.spec_from_file_location("coins_mod", SP + "/dec/live2/coins.py")
src = open(SP + "/dec/live2/coins.py").read().split("mints = sorted(")[0]
g = {}; exec(src, g)
seed = g["seed"]
night = SP + "/dec/night/ops.json"
ops = json.load(open(night)) if os.path.exists(night) else {}
w2c = collections.defaultdict(list)
pre = json.load(open(SP + "/dec/cell/prebuy.json"))
for op, ms in ops.items():
    for m, d in ms.items():
        for w in d.get("wallets", []): w2c[w].append(m)
for p in sys.argv[1:]:
    m = next(k for k in D["us"] if k.startswith(p))
    i = g["coin"](m)
    f = "dev" if i["dev_fees"] else "third"
    print(p, i["uri_host"], "dev", i["dev_buy"], f, "pb", i["pb"], "holder", i["holder"], "tail", i["tail"])
    for w in i["bw"]:
        r = seed.get(f"{w}:{f}"); cs = w2c.get(w, [])
        hosts = collections.Counter((pre.get(c, {}).get("create") or {}).get("uri", "?").split("//")[-1].split("/")[0] for c in cs)
        he = sum(pre.get(c, {}).get("he", 0) for c in cs)
        print("   ", w[:8], "record", r[:2] if r else None, "night coins", len(cs), "he took", he, dict(hosts.most_common(3)))
