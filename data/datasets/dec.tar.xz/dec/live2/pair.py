# Our attempts since a time and his trades on the same mints (chain only).
import sys, json, time, datetime, threading
from concurrent.futures import ThreadPoolExecutor
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month"); sys.path.insert(0, SP + "/rivalpnl"); sys.path.insert(0, "/home/user/rugsnipe/analysis")
import tri, pumpparse as PP, common as C
from rugsnipe_analysis import events as E
tri.MIN_GAP = 0.015
A = "AHwJSnFNUiAU9FfT5ewW2osqMo938WtL7KhfsJyfpaN2"; US = "4g49xGbgHZk3QYR1o6QSfDUbHmJZFwN6iDp6Vco1skff"
U = lambda x: datetime.datetime.fromtimestamp(x, datetime.timezone.utc)
T0 = int(datetime.datetime(2026, 10, 25, 14, 50, tzinfo=datetime.timezone.utc).timestamp()); T1 = int(time.time())
def sigs(addr, lo):
    out = []; before = None
    for _ in range(20):
        o = {"limit": 1000}
        if before: o["before"] = before
        s = tri.rpc("getSignaturesForAddress", [addr, o], cache=False) or []
        out += [x for x in s if (x.get("blockTime") or 0) >= lo]
        if len(s) < 1000 or (s[-1].get("blockTime") or 0) < lo: break
        before = s[-1]["signature"]
    return out
def walk(addr):
    rows = {}; lock = threading.Lock()
    def one(x):
        t = tri.tx(x["signature"])
        if not t: return
        ks = PP.keys_of(t)
        if ks[0] != addr: return
        err = (t.get("meta") or {}).get("err")
        m = None; buy = sell = False
        for prog, accs, data, parsed, oi, inner in PP._ixs(t, ks):
            if prog == C.PUMP and not inner and data[:8] in PP.IXR:
                n = PP.IXR[data[:8]]
                if n.startswith("buy"): buy = True; m = accs[2] if len(accs) > 2 else m
                if n.startswith("sell"): sell = True; m = accs[2] if len(accs) > 2 else m
        sp = got = 0
        for prog, accs, data, parsed, oi, inner in PP._ixs(t, ks):
            if prog == C.PUMP and data and data[:8] == E.EVENT_IX_TAG and data[8:16] == E.DISC_TRADE:
                try: e = E.decode_trade(data[8:])
                except Exception: continue
                if e.user != addr: continue
                m = m or e.mint
                if e.is_buy: sp += e.sol_amount + (e.fee or 0) + (e.creator_fee or 0)
                else: got += e.sol_amount - (e.fee or 0) - (e.creator_fee or 0)
        tbm = [b["mint"] for b in (t["meta"].get("postTokenBalances") or []) + (t["meta"].get("preTokenBalances") or []) if b["mint"] != "So11111111111111111111111111111111111111112"]
        if tbm and (m is None or m.startswith("So1111")): m = tbm[0]
        if not m or m.startswith("So1111") or not (buy or sell): return
        fee = (t.get("meta") or {}).get("fee", 0)
        with lock:
            r = rows.setdefault(m, dict(buys=0, failed=0, sells=0, spent=0, got=0, fees=0, slot=None, bt=None))
            if buy:
                r["buys"] += 1; r["failed"] += err is not None
                if err is not None: r["err"] = str(err)[:60]
                r["slot"] = min(r["slot"] or t["slot"], t["slot"]); r["bt"] = min(r["bt"] or x["blockTime"], x["blockTime"])
            if sell and err is None: r["sells"] += 1
            r["spent"] += sp; r["got"] += got; r["fees"] += fee
    with ThreadPoolExecutor(8) as ex: list(ex.map(one, sigs(addr, T0 - 60)))
    return rows
us = walk(US); him = walk(A)
print("window", U(T0).strftime("%H:%M"), "->", U(T1).strftime("%H:%M"), "UTC")
print("our attempted mints", len(us), " his attempted mints", sum(1 for r in him.values() if r["buys"]))
print(f"{'time':8} {'mint':9} {'us':10} {'us_net':>8} {'him':10} {'him_net':>8} {'him_pct':>7}")
for m, r in sorted(us.items(), key=lambda kv: kv[1]["bt"] or 0):
    h = him.get(m)
    ok = r["buys"] - r["failed"]
    usn = (r["got"] - r["spent"] - r["fees"]) / 1e9
    us_s = "landed" if ok else "failed"
    if h and h["buys"]:
        hok = h["buys"] - h["failed"]
        hn = (h["got"] - h["spent"]) / 1e9
        hp = 100 * (h["got"] / h["spent"] - 1) if h["spent"] and h["sells"] else float("nan")
        h_s = ("bought" if hok else "failed") + ("" if h["sells"] or not hok else "/open")
        print(f"{U(r['bt']).strftime('%H:%M:%S')} {m[:8]:9} {us_s:10} {usn:8.4f} {h_s:10} {hn:8.4f} {hp:7.1f}")
    else:
        print(f"{U(r['bt']).strftime('%H:%M:%S')} {m[:8]:9} {us_s:10} {usn:8.4f} {'skipped':10}", r.get("err", ""))
hb = {m: h for m, h in him.items() if h["buys"]}
both = [m for m in hb if m in us]
hn_all = sum((h["got"] - h["spent"]) / 1e9 for h in hb.values() if h["sells"])
print("his coins in the window", len(hb), "of them we attempted", len(both), " his net on sold coins (curve, before tips)", round(hn_all, 4))
json.dump(dict(us=us, him=him, T0=T0, T1=T1), open(SP + "/dec/live2/pair.json", "w"))
