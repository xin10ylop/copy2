# Our failed buys (6042: the price passed our cap, entry.max_premium): where would we have bought (the price at our
# transaction's position in its slot, against the post-bundle price), and what was that entry worth at create + 3 / + 10.
import sys, json, os, collections, statistics as st
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
OUT = SP + "/dec/live2/day"
A = "AHwJSnFNUiAU9FfT5ewW2osqMo938WtL7KhfsJyfpaN2"; US = "4g49xGbgHZk3QYR1o6QSfDUbHmJZFwN6iDp6Vco1skff"
exec(open(SP + "/dec/live2/day_an.py").read().split("def per_mint")[0].replace("SINCE = int(sys.argv[1]) if len(sys.argv) > 1 else 0", "SINCE = 0"))
COST = 0.059  # measured on our landed trades today: spot value at our sell slot +4.6% -> realized net -1.3%
def at(t, slot, idx):
    xs = [r for r in t["rows"] if (r[0], r[1]) < (slot, idx) and r[6] > 0]
    return xs[-1][5] / xs[-1][6] if xs else None
def px(t, s):
    xs = [r for r in t["rows"] if r[0] <= s and r[6] > 0]
    return xs[-1][5] / xs[-1][6] if xs else None
B = collections.defaultdict(lambda: {3: [], 10: []})
seen = set(); landed = {r["m"] for r in us if r["kind"] == "buy" and r["ok"]}
for r in sorted(us, key=lambda r: (r["slot"], r["idx"])):
    if r["kind"] != "buy" or r["ok"] or r["code"] != 6042 or r["m"] in seen or r["m"] in landed: continue
    seen.add(r["m"])
    t = tape(r["m"]); ru = run(t) if t else None
    if not ru: continue
    p = at(t, r["slot"], r["idx"])
    if not p: continue
    prem = p / ru["p0"] - 1
    b = "<2%" if prem < 0.02 else "2-5%" if prem < 0.05 else "5-10%" if prem < 0.10 else "10-20%" if prem < 0.20 else "20-40%" if prem < 0.4 else "40%+"
    for k in (3, 10):
        q = px(t, ru["cs"] + k)
        if q: B[b][k].append(q / p - 1)
print("our failed buys today (6042), by how far above the post-bundle price the price was at our position:")
print(f"{'premium':8} {'coins':>5} {'spot +3':>8} {'spot +10':>9} {'est. net +3':>11} {'est. net +10':>12}")
order = ["<2%", "2-5%", "5-10%", "10-20%", "20-40%", "40%+"]
for b in order:
    if b not in B: continue
    a3, a10 = B[b][3], B[b][10]
    f = lambda xs: f"{100*st.mean(xs):+7.1f}%" if xs else "      -"
    print(f"{b:8} {len(a10):5d} {f(a3):>8} {f(a10):>9} {f([x - COST for x in a3]):>11} {f([x - COST for x in a10]):>12}")
