# The burst operator's funders: their outgoing SOL transfers -> the wallets they funded -> those wallets' records in the
# seed (Oct 23-25 + today) -> his attempts and runs over the whole cluster.
import sys, json, collections
from concurrent.futures import ThreadPoolExecutor
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month"); sys.path.insert(0, SP + "/rivalpnl"); sys.path.insert(0, "/home/user/rugsnipe/analysis")
import tri, pumpparse as PP
tri.MIN_GAP = 0.015
def sigs(a, pages):
    out = []; before = None
    for _ in range(pages):
        o = {"limit": 1000}
        if before: o["before"] = before
        s = tri.rpc("getSignaturesForAddress", [a, o], cache=False) or []
        out += s
        if len(s) < 1000: break
        before = s[-1]["signature"]
    return out
seed = json.load(open("/home/user/rugsnipe/data/follow_seed.json"))
today = json.load(open("/home/user/rugsnipe/data/follow_seed_today.json"))
for F in sys.argv[1:]:
    ss = [x for x in sigs(F, 30) if not x.get("err")]
    print(F[:8], "signatures", len(ss), "slots", min(x["slot"] for x in ss), "-", max(x["slot"] for x in ss))
    got = collections.defaultdict(float)
    def one(x):
        t = tri.tx(x["signature"])
        if not t: return []
        return [(dst, lam / 1e9, t["slot"]) for src, dst, lam, inner in PP.analyze(t)["sysxfers"] if src == F and dst != F]
    with ThreadPoolExecutor(8) as ex: xs = [r for rs in ex.map(one, ss) for r in rs]
    funded = collections.defaultdict(list)
    for d, sol, sl in xs: funded[d].append((sl, sol))
    print("  funded wallets", len(funded))
    agg = collections.Counter(); per = []
    for w in funded:
        for k, v in list(seed.items()) + [("T" + k, v) for k, v in today.items()]:
            kk = k[1:] if k.startswith("T") else k
            if kk.split(":")[0] == w:
                agg[("today" if k.startswith("T") else "seed", kk.split(":")[1], "runs")] += v[0]
                agg[("today" if k.startswith("T") else "seed", kk.split(":")[1], "att")] += v[1]
                per.append((w[:8], k[:1] == "T", kk.split(":")[1], v[:2]))
    print("  wallets in the seed/today", len({p[0] for p in per}))
    for k in sorted(agg): print("   ", k, agg[k])
    print("  ", per[:30])
    json.dump(dict(funded={w: v for w, v in funded.items()}), open(SP + f"/dec/live2/cluster_{F[:8]}.json", "w"))
