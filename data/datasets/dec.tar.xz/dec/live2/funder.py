# The burst operator (fresh dev + 4 fresh bundle wallets per coin, dev 0.99, pb 50.0, holder mode): who funded each
# coin's wallets, and that funder's other fundings -> all its coins; his take on each.
import sys, json, datetime, collections
from concurrent.futures import ThreadPoolExecutor
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month"); sys.path.insert(0, SP + "/rivalpnl"); sys.path.insert(0, "/home/user/rugsnipe/analysis")
import tri, pumpparse as PP, common as C
tri.MIN_GAP = 0.015
info = json.load(open(SP + "/dec/live2/coins.json"))
burst = {m: i for m, i in info.items() if i and i.get("pb") == 50.0}
def funders(w):
    s = tri.rpc("getSignaturesForAddress", [w, {"limit": 100}], cache=False) or []
    s = sorted(s, key=lambda x: x["slot"])[:3]
    out = []
    for x in s:
        t = tri.tx(x["signature"])
        if not t: continue
        ks = PP.keys_of(t)
        pre, post = t["meta"]["preBalances"], t["meta"]["postBalances"]
        if w in ks:
            j = ks.index(w)
            if post[j] > pre[j] and ks[0] != w: out.append((ks[0], (post[j] - pre[j]) / 1e9, x["slot"], x.get("blockTime")))
    return out
rows = {}
def one(m):
    i = burst[m]; ws = [i["signer"]] + i["bw"]
    return m, {w: funders(w) for w in ws}
with ThreadPoolExecutor(8) as ex: res = dict(ex.map(one, list(burst)))
cnt = collections.Counter()
for m, d in res.items():
    print(m[:8])
    for w, f in d.items():
        print("   ", w[:8], [(a[:8], round(b, 3), c) for a, b, c, _ in f][:2])
        for a, *_ in f[:1]: cnt[a] += 1
print(cnt.most_common(10))
json.dump(res, open(SP + "/dec/live2/funders.json", "w"))
