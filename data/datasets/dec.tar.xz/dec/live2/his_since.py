# Every coin he attempted under the new config (14:50:59 -> our kill at 15:35:30): his result, ours (sent? landed?
# failed why?), and the coin as our rule sees it (from chain).
import sys, json, os, datetime, collections
from concurrent.futures import ThreadPoolExecutor
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
OUT = SP + "/dec/live2/day"
A = "AHwJSnFNUiAU9FfT5ewW2osqMo938WtL7KhfsJyfpaN2"; US = "4g49xGbgHZk3QYR1o6QSfDUbHmJZFwN6iDp6Vco1skff"
T0, T1 = 1792939859, 1792942530
src = open(SP + "/dec/live2/coins.py").read().split("mints = sorted(")[0]
g = {}; exec(src, g)
U = lambda x: datetime.datetime.fromtimestamp(x, datetime.timezone.utc).strftime("%H:%M:%S")
def W(a): return json.load(open(f"{OUT}/walk_{a[:6]}.json"))["rows"]
him = [r for r in W(A) if T0 <= (r["bt"] or 0) < T1]; us = W(US)
H = collections.defaultdict(lambda: dict(buys=0, ok=0, net=0, bt=None, codes=collections.Counter()))
for r in W(A):
    if r["m"] not in {x["m"] for x in him}: continue
    d = H[r["m"]]; d["net"] += r["delta"]
    if r["kind"] == "buy":
        d["buys"] += 1; d["ok"] += r["ok"]; d["bt"] = min(d["bt"] or r["bt"], r["bt"])
        if not r["ok"]: d["codes"][r["code"]] += 1
H = {m: d for m, d in H.items() if d["buys"] and T0 <= d["bt"] < T1}
O = collections.defaultdict(lambda: dict(buys=0, ok=0, codes=collections.Counter(), net=0))
for r in us:
    d = O[r["m"]]; d["net"] += r["delta"]
    if r["kind"] == "buy":
        d["buys"] += 1; d["ok"] += r["ok"]
        if not r["ok"]: d["codes"][r["code"]] += 1
cache = json.load(open(SP + "/dec/live2/coins.json"))
need = [m for m in H if not cache.get(m)]
with ThreadPoolExecutor(8) as ex: cache.update(dict(zip(need, ex.map(g["coin"], need))))
json.dump(cache, open(SP + "/dec/live2/coins.json", "w"))
rows = []
for m, h in sorted(H.items(), key=lambda kv: kv[1]["bt"]):
    i = cache.get(m) or {}; o = O.get(m)
    if o and o["buys"]: ours = "LANDED" if o["ok"] else "sent, failed " + ",".join(str(c) for c in o["codes"])
    else: ours = "not sent"
    hs = "landed" if h["ok"] else "failed " + ",".join(str(c) for c in h["codes"])
    rows.append((U(h["bt"]), m, hs, h["net"] / 1e9, ours, i.get("uri_host"), i.get("dev_buy"), "dev" if i.get("dev_fees") else "third",
                 len(i.get("bw") or []), i.get("pb"), "yes" if i.get("followed") else "no", "holder" if i.get("holder") else "plain"))
print(f"{'time':8} {'mint':8} {'him':12} {'his_net':>8} {'ours':20} {'uri host':22} {'dev':>6} {'fees':5} {'bw':>2} {'pb':>5} {'fol':3} mode")
for r in rows:
    print(f"{r[0]} {r[1][:8]} {r[2]:12} {r[3]:+8.4f} {r[4]:20} {str(r[5])[:22]:22} {r[6] if r[6] is not None else 0:6.2f} {r[7]:5} {r[8]:2d} {str(r[9]):>5} {r[10]:3} {r[11]}")
c = collections.Counter(); s = collections.Counter()
for r in rows:
    k = r[4].split(",")[0] if r[4] != "not sent" else "not sent"
    k = ("we landed" if k == "LANDED" else "we sent, failed" if k.startswith("sent") else "we did not send")
    c[(k, r[2].split()[0])] += 1; s[(k, r[2].split()[0])] += r[3]
print()
for k in sorted(c): print(f"   {k[0]:16s} he {k[1]:7s} coins {c[k]:3d}  his net {s[k]:+.4f} SOL")
json.dump([list(r) for r in rows], open(SP + "/dec/live2/his_since.json", "w"))
print("\nprefixes:", " ".join(r[1][:8] for r in rows if r[4] == "not sent"))
