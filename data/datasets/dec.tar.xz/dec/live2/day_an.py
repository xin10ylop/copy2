# Today: the backtest's assumption (fill every fire as the first outside buyer at the post-bundle price, sell at create
# + k) against what happened, for us and for him, from chain.
import sys, json, os, datetime, collections, statistics as st
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
OUT = SP + "/dec/live2/day"
A = "AHwJSnFNUiAU9FfT5ewW2osqMo938WtL7KhfsJyfpaN2"; US = "4g49xGbgHZk3QYR1o6QSfDUbHmJZFwN6iDp6Vco1skff"
SINCE = int(sys.argv[1]) if len(sys.argv) > 1 else 0
def W(a): return [r for r in json.load(open(f"{OUT}/walk_{a[:6]}.json"))["rows"] if (r["bt"] or 0) >= SINCE]
us, him = W(US), W(A)
def tape(m):
    p = f"{OUT}/tape/{m}.json"
    return json.load(open(p)) if os.path.exists(p) else None
def run(t):
    c = t.get("create")
    if not c: return None
    cs, ci = c["slot"], c["idx"]; prev = ci; last = None; seen_c = set()
    for s, i, u, b, sol, v, tk, cr in t["rows"]:
        if s != cs or (s, i) < (cs, ci): continue
        if i == ci: last = (v, tk); seen_c.add(u); continue
        if b and u not in (A, US) and i - prev <= 2 and i - ci <= 5: prev = i; last = (v, tk)
    if not last: return None
    p0 = last[0] / last[1]
    out = dict(cs=cs, p0=p0, pb=last[0] / 1e9)
    for k in (1, 3, 10):
        xs = [r for r in t["rows"] if r[0] <= cs + k and r[6] > 0]
        out[k] = xs[-1][5] / xs[-1][6] / p0 - 1 if xs else None
    return out
def per_mint(rows, who):
    g = collections.defaultdict(lambda: dict(buys=0, ok=0, codes=collections.Counter(), net=0, bsol=0, btok=0, ssol=0, stok=0, bslot=None, sslot=None, bt=None))
    for r in rows:
        d = g[r["m"]]; d["net"] += r["delta"]; d["bt"] = min(d["bt"] or r["bt"], r["bt"])
        if r["kind"] == "buy":
            d["buys"] += 1
            if r["ok"] and r["fill"]:
                d["ok"] += 1; d["bsol"] += r["fill"][0]; d["btok"] += r["fill"][1]; d["bslot"] = min(d["bslot"] or r["slot"], r["slot"])
            elif not r["ok"]: d["codes"][r["code"]] += 1
        elif r["ok"] and r["fill"]:
            d["ssol"] += r["fill"][0]; d["stok"] += r["fill"][1]; d["sslot"] = max(d["sslot"] or r["slot"], r["slot"])
    return {m: d for m, d in g.items() if d["buys"]}
U, H = per_mint(us, "us"), per_mint(him, "him")
def pct(xs): return f"{100*st.mean(xs):+6.1f}%" if xs else "    - "
def med(xs): return f"{100*st.median(xs):+6.1f}%" if xs else "    - "
def show(name, P, other):
    rs = {m: run(t) for m in P for t in [tape(m)] if t}
    n = len(P); land = [m for m, d in P.items() if d["ok"]]; fail = [m for m in P if m not in land]
    print(f"\n== {name}: attempted {n} coins, landed {len(land)} ({100*len(land)/max(1,n):.0f}%), failed {len(fail)}  failure codes {dict(sum((P[m]['codes'] for m in fail), collections.Counter()).most_common(4))}")
    for lab, ms in (("landed", land), ("failed", fail)):
        v3 = [rs[m][3] for m in ms if rs.get(m) and rs[m][3] is not None]; v10 = [rs[m][10] for m in ms if rs.get(m) and rs[m][10] is not None]
        print(f"   {lab:7s} coins {len(ms):4d}  backtest value (fill at post-bundle, gross) at +3 {pct(v3)} (median {med(v3)}), at +10 {pct(v10)} (median {med(v10)})  n {len(v10)}")
    closed = [m for m in land if P[m]["stok"] > 0]
    ent = [P[m]["bsol"] / P[m]["btok"] / rs[m]["p0"] - 1 for m in closed if rs.get(m) and P[m]["btok"]]
    gross = [P[m]["ssol"] / P[m]["bsol"] - 1 for m in closed if P[m]["bsol"]]
    net = [P[m]["net"] / P[m]["bsol"] for m in closed if P[m]["bsol"]]
    bt10 = [rs[m][10] for m in closed if rs.get(m) and rs[m][10] is not None]
    hold = collections.Counter(min((P[m]["sslot"] or 0) - rs[m]["cs"], 99) for m in closed if rs.get(m))
    eslot = collections.Counter((P[m]["bslot"] - rs[m]["cs"]) for m in closed if rs.get(m))
    print(f"   landed and sold {len(closed)}: entry price vs post-bundle {pct(ent)} (median {med(ent)}); entry slot {dict(sorted(eslot.items()))}; sold at create + {dict(sorted(hold.items()))}")
    print(f"      the backtest's value on these coins (+10, gross) {pct(bt10)}; realized curve gross {pct(gross)}; realized net (wallet: fees, tips, failed sends) {pct(net)}")
    # exit check: the price just before our sell (the last trade before it, any wallet) against our sell's price
    def pre_sell(m):
        t = tape(m); d = P[m]
        if not t or not d["sslot"]: return None
        xs = [r for r in t["rows"] if r[0] < d["sslot"] or (r[0] == d["sslot"] and r[2] != (US if name == "US" else A))]
        xs = [r for r in xs if r[0] <= d["sslot"]]
        return xs[-1][5] / xs[-1][6] / rs[m]["p0"] - 1 if xs and rs.get(m) else None
    at_exit = [(m, pre_sell(m)) for m in closed]
    at_exit = [(m, v) for m, v in at_exit if v is not None]
    sold = [P[m]["ssol"] / P[m]["stok"] / rs[m]["p0"] - 1 for m, v in at_exit if P[m]["stok"]]
    print(f"      the backtest's value at our own sell slot {pct([v for m, v in at_exit])}; our sell price vs post-bundle {pct(sold)}")
    tot_net = sum(d["net"] for d in P.values()) / 1e9
    print(f"   wallet net on everything attempted {tot_net:+.4f} SOL; on landed {sum(P[m]['net'] for m in land)/1e9:+.4f}; failed sends cost {sum(P[m]['net'] for m in fail)/1e9:+.4f}")
    both = [m for m in P if m in other]
    print(f"   attempted by the other too: {len(both)}  landed here {sum(1 for m in both if P[m]['ok'])}, landed there {sum(1 for m in both if other[m]['ok'])}")
    for lab, ms in (("other attempted", [m for m in land if m in other]), ("other did not", [m for m in land if m not in other])):
        nn = [P[m]["net"] / P[m]["bsol"] for m in ms if P[m]["bsol"] and P[m]["stok"]]
        print(f"   landed, {lab:15s}: {len(ms):3d} trades, realized net {pct(nn)}, sum {sum(P[m]['net'] for m in ms)/1e9:+.4f} SOL")
    return rs
print("since", datetime.datetime.fromtimestamp(SINCE, datetime.timezone.utc).strftime("%H:%M UTC") if SINCE else "00:00 UTC")
ru = show("US", U, H); rh = show("HIM", H, U)
# contested coins: who landed first
both = [m for m in U if m in H]
c = collections.Counter()
for m in both:
    c[("us landed" if U[m]["ok"] else "us failed", "he landed" if H[m]["ok"] else "he failed")] += 1
print("\ncontested coins:", dict(c))
json.dump(dict(U={m: {k: v for k, v in d.items() if k != "codes"} for m, d in U.items()}, H={m: {k: v for k, v in d.items() if k != "codes"} for m, d in H.items()}), open(OUT + "/permint.json", "w"))
