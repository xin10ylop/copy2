# Did he send anything (landed or failed) on these coins' bonding curves?
import sys, json
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month"); sys.path.insert(0, SP + "/rivalpnl"); sys.path.insert(0, "/home/user/rugsnipe/analysis")
import tri, pumpparse as PP, common as C
A = "AHwJSnFNUiAU9FfT5ewW2osqMo938WtL7KhfsJyfpaN2"; US = "4g49xGbgHZk3QYR1o6QSfDUbHmJZFwN6iDp6Vco1skff"
D = json.load(open(SP + "/dec/live2/pair.json"))
for p in sys.argv[1:]:
    m = next(k for k in D["us"] if k.startswith(p))
    s = tri.rpc("getSignaturesForAddress", [C.bonding_curve(m), {"limit": 1000}], cache=False) or []
    cs = min(x["slot"] for x in s)
    who = []
    for x in sorted(s, key=lambda x: x["slot"]):
        if x["slot"] > cs + 4: break
        t = tri.tx(x["signature"])
        if t and PP.keys_of(t)[0] in (A, US): who.append(("him" if PP.keys_of(t)[0] == A else "us", x["slot"] - cs, "err" if x.get("err") else "ok"))
    print(p, "txs in the first 5 slots", sum(1 for x in s if x["slot"] <= cs + 4), who)
