import sys, json, datetime
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month"); sys.path.insert(0, SP + "/rivalpnl"); sys.path.insert(0, "/home/user/rugsnipe/analysis")
import tri, pumpparse as PP, common as C
US = "4g49xGbgHZk3QYR1o6QSfDUbHmJZFwN6iDp6Vco1skff"
T0 = int(datetime.datetime(2026, 10, 25, 14, 50, tzinfo=datetime.timezone.utc).timestamp())
s = tri.rpc("getSignaturesForAddress", [US, {"limit": 100}], cache=False) or []
s = [x for x in s if (x.get("blockTime") or 0) >= T0]
print(len(s))
for x in s[:40]:
    t = tri.tx(x["signature"]); ks = PP.keys_of(t)
    progs = [(prog[:6], PP.IXR.get(data[:8], data[:8].hex() if data else "")[:14], int(bool(inner)), (accs[2][:6] if len(accs) > 2 else "")) for prog, accs, data, parsed, oi, inner in PP._ixs(t, ks)]
    tb = sorted({b["mint"][:8] for b in (t["meta"].get("postTokenBalances") or []) + (t["meta"].get("preTokenBalances") or [])})
    print(datetime.datetime.fromtimestamp(x["blockTime"], datetime.timezone.utc).strftime("%H:%M:%S"), "err" if x.get("err") else "ok ", ks[0][:6], tb, [p for p in progs if p[0] not in ("Comput",)][:6])
