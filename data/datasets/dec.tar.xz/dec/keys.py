# Ex ante, per coin of every create with a bundle-slot tape (Oct 23 - Oct 24 12:00): which of its keys his history
# already knew (he attempted an earlier coin with that bundle wallet / creator / signer), and his take by combination.
import json, glob, collections
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
TOOLS = ("metadata.j7tracker.io", "meta.uxento.io", "m.rapidlaunch.io")
TEMPLATE = lambda d: (0.95 <= d < 1.05) or (2.95 <= d < 4.05) or (4.95 <= d < 5.05) or d >= 7
BW = json.load(open(SP + "/dec/bwall.json"))
cr = {}
for f in glob.glob(SP + "/univ/creates_*.json"):
    for c in json.load(open(f)): cr[c["mint"]] = c
D = {}
for day in (23, 24):
    for r in json.load(open(SP + f"/pm/dataset_{day}.json")):
        r["per"] = "23a" if day == 23 and r["hour"] < 12 else "23b" if day == 23 else ("24a" if r["hour"] < 12 else "24b")
        D[r["mint"]] = r
ALL = sorted((cr[m]["slot"], cr[m]["idx"] or 0, m) for m in D if m in cr and D[m]["per"] != "24b")
kb = collections.Counter(); kc = collections.Counter(); ks = collections.Counter()   # his attempts per key so far
nb = collections.Counter(); nc = collections.Counter(); ns = collections.Counter()   # coins per key so far
st = collections.defaultdict(lambda: [0, 0])
for s, i, m in ALL:
    r = D[m]; c = cr[m]; ws = BW.get(m, {}).get("bw", []) if m in BW else []
    he = r["he"]
    B = any(kb[w] >= 1 for w in ws); Bf = any(kb[w] >= 2 and kb[w] / nb[w] >= 0.5 for w in ws)
    Cr = kc[c["creator"]] >= 1; Sg = ks[c["signer"]] >= 1
    if r["per"] != "23a" and r["dev"] >= 0.25 and ws:
        k = ("B followed" if Bf else "B known" if B else "B new") + " | " + ("creator known" if Cr else "creator new") + " | " + ("signer known" if Sg else "signer new")
        st[k][0] += 1; st[k][1] += he
    for w in ws: nb[w] += 1; kb[w] += he
    nc[c["creator"]] += 1; kc[c["creator"]] += he; ns[c["signer"]] += 1; ks[c["signer"]] += he
print("bundled coins, dev >= 0.25, Oct 23 12-24 + Oct 24 00-12 (history from Oct 23 00:00), by what his history knew:")
tot = sum(v[1] for v in st.values())
for k in sorted(st, key=lambda k: -st[k][0]):
    n, h = st[k]; print(f"   {k:48s} coins {n:6d} he took {h:4d} ({100*h/n:5.1f}%)  share of his {100*h/tot:4.1f}%")
