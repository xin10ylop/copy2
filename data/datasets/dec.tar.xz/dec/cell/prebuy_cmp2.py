# The mixed cells' launches with separate bundle transactions (the structure he can take): pre-buy features, temporal
# split inside each cell, plus the size pattern against the operator's own usual sizes and the launch cadence.
import json, collections, statistics as st
exec(open("prebuy_cmp.py").read().split("cell = collections.defaultdict(list)")[0])
exec(open("structure.py").read().split("cell = collections.defaultdict(list)")[0].split("S = json.load")[1].join(["S = json.load", ""]) if False else "")
from structure import struct  # noqa
