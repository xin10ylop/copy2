# Our own buys of Oct 21-25 (the 5-day walks) by the tip we paid: where they landed after the create (create slot or
# later, block positions after the create) and how often the price limit refused them (code 6042), from the chain.
import json, collections, statistics as st, glob
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
exec(open(SP + "/dec/behind/second.py").read().split("# ---- A.")[0])
B = json.load(open(SP + "/dec/five/bids.json"))
crm = {}
for p in glob.glob(SP + "/dec/five/coin/*.json"):
    d = json.load(open(p))
    if d.get("create"): crm[d["mint"]] = (d["cs"], d["create"]["idx"])
rows = []
for r in W[US]:
    if r["kind"] != "buy" or r["m"] not in crm: continue
    cs, ci = crm[r["m"]]
    if r["slot"] > cs + 2: continue
    tip = (B.get(r["sig"]) or [None])[0]
    if tip is None: continue
    rows.append(dict(tip=tip, same=r["slot"] == cs, pos=(r["idx"] - ci) if r["slot"] == cs else None, ok=bool(r["ok"]), slip=r.get("code") == 6042))
print(f"{len(rows)} of our buys with a known tip")
print(f"{'our tip':>10} {'buys':>5} {'in create slot':>15} {'median position':>16} {'p25':>5} {'refused 6042':>13} {'landed ok':>10}")
for lo, hi in ((0, 1.2e6), (1.2e6, 2e6), (2e6, 3.5e6), (3.5e6, 5e6), (5e6, 8e6), (8e6, 1e12)):
    s = [r for r in rows if lo <= r["tip"] < hi]
    if not s: continue
    ps = sorted(r["pos"] for r in s if r["pos"] is not None)
    print(f"{lo/1e6:4.1f}-{hi/1e6 if hi < 1e11 else 99:4.1f}M {len(s):5d} {100 * sum(r['same'] for r in s) / len(s):14.0f}% {st.median(ps) if ps else '-':>16} {ps[len(ps)//4] if ps else '-':>5} {100 * sum(r['slip'] for r in s) / len(s):12.0f}% {100 * sum(r['ok'] for r in s) / len(s):9.0f}%")
