# Ex ante: each bundle-wallet set's habit so far (does it reuse its creator wallet, its signer?) and whether this coin
# matches the habit. His take on coins of followed wallet sets, on-profile vs off-profile.
import json, glob, collections
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
BW = json.load(open(SP + "/dec/bwall.json"))
cr = {}
for f in glob.glob(SP + "/univ/creates_*.json"):
    for c in json.load(open(f)): cr[c["mint"]] = c
D = {}
for day in (23, 24):
    for r in json.load(open(SP + f"/pm/dataset_{day}.json")):
        r["per"] = "23a" if day == 23 and r["hour"] < 12 else "23b" if day == 23 else ("24a" if r["hour"] < 12 else "24b")
        D[r["mint"]] = r
P = {}
def find(x):
    while P.setdefault(x, x) != x: P[x] = P[P[x]]; x = P[x]
    return x
fan = collections.Counter(w for x in BW.values() for w in x["bw"])
for m, x in BW.items():
    ws = [w for w in x["bw"] if fan[w] <= 400]
    for w in ws[1:]: P[find(ws[0])] = find(w)
ALL = sorted((cr[m]["slot"], cr[m]["idx"] or 0, m) for m in D if m in cr and D[m]["per"] != "24b")
kb = collections.Counter(); nb = collections.Counter()
hist = collections.defaultdict(lambda: dict(n=0, cre=collections.Counter(), sig=collections.Counter(), dev=collections.Counter(), reuse_c=0, reuse_s=0))
st = collections.defaultdict(lambda: [0, 0])
for s, i, m in ALL:
    r = D[m]; c = cr[m]; ws = [w for w in BW.get(m, {}).get("bw", []) if fan[w] <= 400] if m in BW else []
    he = r["he"]
    if ws:
        o = find(ws[0]); h = hist[o]
        fol = any(kb[w] >= 2 and kb[w] / nb[w] >= 0.5 for w in ws)
        if r["per"] != "23a" and r["dev"] >= 0.25 and fol and h["n"] >= 3:
            c_known = h["cre"][c["creator"]] > 0; s_known = h["sig"][c["signer"]] > 0; d_known = h["dev"][round(r["dev"], 2)] > 0
            c_habit = h["reuse_c"] / h["n"] >= 0.5   # it usually reuses a creator wallet
            s_habit = h["reuse_s"] / h["n"] >= 0.5
            on_c = (c_known == c_habit); on_s = (s_known == s_habit)
            k = ("creator on-profile" if on_c else "creator OFF-profile") + " | " + ("signer on" if on_s else "signer OFF") + " | " + ("dev seen" if d_known else "dev new")
            st[k][0] += 1; st[k][1] += he
        h["reuse_c"] += h["cre"][c["creator"]] > 0; h["reuse_s"] += h["sig"][c["signer"]] > 0
        h["cre"][c["creator"]] += 1; h["sig"][c["signer"]] += 1; h["dev"][round(r["dev"], 2)] += 1; h["n"] += 1
    for w in ws: nb[w] += 1; kb[w] += he
tot = sum(v[1] for v in st.values()); n_all = sum(v[0] for v in st.values())
print(f"coins of followed wallet sets (3+ prior coins), Oct 23 12-24 + Oct 24 00-12: {n_all}, he took {tot}")
for k in sorted(st, key=lambda k: -st[k][0]):
    n, h = st[k]; print(f"   {k:58s} coins {n:5d} he took {h:4d} ({100*h/n:5.1f}%)")
