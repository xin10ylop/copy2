# The money behind last night's operators: for each bundle wallet of the 58 operators, the SOL that came in (from whom,
# when) and went out (to whom) in the window, from its own transactions. -> dec/night/flows.json
import sys, json, os, time, collections, threading
from concurrent.futures import ThreadPoolExecutor
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
src = open(SP + "/dec/night.py").read()
exec(src.split("# 1. his attempts")[0])
tri.MIN_GAP = 0.03
ops = json.load(open(OUT + "/ops.json"))
W = sorted({w for o, cs in ops.items() for m, c in cs.items() for w in c["wallets"]})
log("operator wallets", len(W))
P = OUT + "/flows.json"
F = json.load(open(P)) if os.path.exists(P) else {}
lock = threading.Lock()
def one(w):
    if w in F: return
    s, capped = sigs_range(w, TW - 86400, T1 + 3600, 10)
    s = sorted(s, key=lambda x: x["slot"])
    # SOL flows: every transaction that is not a pump trade of the wallet (fund, sweep), and the first/last few overall
    pick = [x for x in s if not x.get("err")]
    inflow, outflow = [], []
    for x in pick[:6] + pick[-6:] + [y for y in pick if y.get("memo")][:0]:
        t = tri.tx(x["signature"])
        if not t: continue
        ks = PP.keys_of(t); meta = t["meta"]
        if w not in ks: continue
        a = PP.analyze(t)
        for src_, dst, lam, inner in a["sysxfers"]:
            if dst == w and src_ != w: inflow.append([t["slot"], src_, lam / 1e9])
            if src_ == w and dst != w and dst not in PP.TIPS: outflow.append([t["slot"], dst, lam / 1e9])
    with lock: F[w] = dict(n=len(s), capped=capped, first=s[0]["slot"] if s else None, last=s[-1]["slot"] if s else None, inflow=inflow, outflow=outflow)
n = [0]
def safe(w):
    try: one(w)
    except Exception as e: log("error", w[:8], tri.red(e)[:80])
    n[0] += 1
    if n[0] % 50 == 0:
        log("wallets", n[0], "of", len(W))
        with lock: json.dump(F, open(P + ".tmp", "w")); os.replace(P + ".tmp", P)
with ThreadPoolExecutor(4) as ex: list(ex.map(safe, W))
json.dump(F, open(P, "w")); log("optrace done", len(F))
