# The tweet behind each followed-operator coin, against his take: author size, verified, reply / original, media,
# engagement, tweet age at the create. Half-taken operators by creator type, and near-all operators.
import json, os, glob, collections, math
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
fol = json.load(open(SP + "/dec/fol_ops_2324.json"))
cr = {}
for f in glob.glob(SP + "/univ/creates_*.json"):
    for c in json.load(open(f)): cr[c["mint"]] = c
D = {}
for day in (23, 24):
    for r in json.load(open(SP + f"/pm/dataset_{day}.json")): D[r["mint"]] = r
def tw(sid):
    p = f"{SP}/dec/tweets/{sid}.json"
    if not sid or not os.path.exists(p): return None
    j = json.load(open(p)); return j.get("tweet")
def bucket(x, edges):
    for e in edges:
        if x < e: return f"<{e:,}"
    return f">={edges[-1]:,}"
rows = []
for o, s in fol.items():
    rate = sum(D[m]["he"] for m in s) / len(s)
    main = collections.Counter(cr[m]["creator"] for m in s).most_common(1)[0][0]
    for m in s:
        r = D[m]; c = cr[m]; t = tw(r["sid"])
        kind = "half" if rate <= 0.85 else "near"
        ctype = "main" if c["creator"] == main else ("signer" if c["creator"] == c["signer"] else "fresh")
        f = {}
        if t:
            a = t.get("author") or {}
            f["followers"] = bucket(a.get("followers") or 0, [1000, 10000, 100000, 1000000])
            f["verified"] = bool((a.get("verification") or {}).get("verified"))
            f["reply"] = "reply" if t.get("replying_to") else "original"
            f["media"] = "media" if t.get("media") else "text"
            f["quote"] = "quote" if t.get("quote") else "-"
            f["views"] = bucket(t.get("views") or 0, [1000, 10000, 100000, 1000000])
            f["likes"] = bucket(t.get("likes") or 0, [10, 100, 1000, 10000])
            f["age at create"] = bucket(max(0, c["bt"] - (t.get("created_timestamp") or c["bt"])), [30, 120, 600, 3600])
        else:
            f["followers"] = "no tweet / deleted"
        rows.append((kind, ctype, r["he"], f))
for scope in (("half", "fresh"), ("half", "main"), ("near", None)):
    g = [x for x in rows if x[0] == scope[0] and (scope[1] is None or x[1] == scope[1])]
    print(f"\n== {scope[0]}-taken operators{', creator = ' + scope[1] if scope[1] else ''}: {len(g)} coins, taken {sum(x[2] for x in g)}")
    for feat in ("followers", "verified", "reply", "media", "quote", "views", "likes", "age at create"):
        st = collections.defaultdict(lambda: [0, 0])
        for x in g:
            v = x[3].get(feat, "n/a"); st[v][0] += 1; st[v][1] += x[2]
        print(f"   {feat:14s} " + " | ".join(f"{k}: {h}/{n} {100*h/n:.0f}%" for k, (n, h) in sorted(st.items(), key=lambda kv: str(kv[0])) if n >= 4))
