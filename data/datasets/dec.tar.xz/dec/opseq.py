# Per operator, every coin in order: its template (dev buy, bundle sizes), the insiders' dump clock, his action and
# result, what the first spot after the bundle was worth. Then: what makes him take or skip an operator's coin.
import json, os, sys, collections
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/pm"); import bt as BT
OUT = SP + "/dec/night"
A, US = BT.A, BT.US
ops = json.load(open(OUT + "/ops.json")); him = json.load(open(OUT + "/him.json"))
def coin(m):
    p = f"{OUT}/coins/{m}.json"
    if not os.path.exists(p): return None
    t = json.load(open(p)); c = t["create"]
    if not c or not any(r[0] > t["cs"] for r in t["rows"]): return None
    cs, ci = c["slot"], c["idx"]
    seq = [(s, i, e) for s, i, sg, evs in t["rows"] for e in evs]
    cset = {c["creator"], c["user"], c["signer"]}; prev = ci; bw = []; dev = 0; bsz = []; pb = None; end = (cs, ci)
    for s, i, e in seq:
        u, b, sol = e[0], e[1], e[2]
        if (s, i) < (cs, ci): continue
        if (s, i) == (cs, ci):
            if u in cset or u == c["user"]: dev += sol if b else 0
            pb = e[4]; continue
        if s == cs and u in cset and (i - prev) <= 2: prev = max(prev, i); pb = e[4]; end = (s, i); continue
        if s == cs and b and u not in (A, US) and (i - prev) <= 2 and (i - ci) <= 5: prev = i; bw.append(u); bsz.append(round(sol / 1e9, 3)); pb = e[4]; end = (s, i)
        elif (s, i) > end: break
    ins = cset | set(bw)
    bought = sum(e[3] for s, i, e in seq if e[0] in ins and e[1] and s == cs)
    sold_by = {}
    acc = 0
    for s, i, e in seq:
        if e[0] in ins and not e[1] and (s, i) > end:
            acc += e[3]
            for k in (1, 2, 3, 5, 8, 12):
                if s - cs <= k and k not in sold_by and bought and acc >= 0.5 * bought: sold_by[k] = True
    first_sell = next((s - cs for s, i, e in seq if e[0] in ins and not e[1] and (s, i) > end), None)
    half = next((k for k in (1, 2, 3, 5, 8, 12) if sold_by.get(k)), None)
    x = BT.coin(c, dict(rows=[[s, i, sg, [e[:7] for e in evs]] for s, i, sg, evs in t["rows"]]))
    vC = x.get("vC") or {}
    h = him.get(m)
    act = "skip"
    if h and h["att"]:
        act = "landed" if h["buy_slot"] else "failed"
    pnl = (h["got"] - h["spent"]) / 1e9 if h and h["buy_slot"] else None
    ret = (h["got"] / h["spent"] - 1) if h and h["buy_slot"] and h["spent"] else None
    hsell = (h["sell_slot"] - cs) if h and h.get("sell_slot") else None
    return dict(m=m, cs=cs, dev=round(dev / 1e9, 3), bsz=bsz, nbw=len(bw), pb=round(pb / 1e9, 2) if pb else None,
                first_sell=first_sell, half=half, act=act, pnl=pnl, ret=ret, hsell=hsell,
                v3=vC.get(3), v10=vC.get(10), fo=x.get("fo_who"))
if __name__ == "__main__":
    big = sorted(ops.items(), key=lambda kv: -len(kv[1]))
    allrows = {}
    for o, cs in big:
        rows = [r for r in (coin(m) for m in sorted(cs, key=lambda m: cs[m]["slot"])) if r]
        allrows[o] = rows
    json.dump(allrows, open(OUT + "/opseq.json", "w"))
    for o, rows in big[:4]:
        rows = allrows[o]
        print(f"\n== operator {o[:8]}: {len(rows)} coins with tapes, he took {sum(r['act'] != 'skip' for r in rows)}")
        print("   time(slot)  dev   bundle sizes        pb   his act  his ret  his sell  insiders: 1st sell / half by   v3      v10")
        for r in rows[:70]:
            print(f"   {r['cs']}  {r['dev']:5.2f} {str(r['bsz'])[:20]:20s} {r['pb'] or 0:5.1f} {r['act']:7s} {('%+.1f%%' % (100*r['ret'])) if r['ret'] is not None else '':>8s} {str(r['hsell']):>6s}   {str(r['first_sell']):>4s} / {str(r['half']):>4s}   {('%+.1f%%' % (100*r['v3'])) if r['v3'] is not None else '-':>7s} {('%+.1f%%' % (100*r['v10'])) if r['v10'] is not None else '-':>7s}")
