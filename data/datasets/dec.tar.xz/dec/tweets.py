# The tweet behind each coin of the followed operators (Oct 23 - Oct 24 12:00), from fxtwitter: author followers,
# reply / quote / media, engagement now. -> dec/tweets/<sid>.json
import json, os, time, urllib.request, collections
from concurrent.futures import ThreadPoolExecutor
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
fol = json.load(open(SP + "/dec/fol_ops_2324.json"))
D = {}
for day in (23, 24):
    for r in json.load(open(SP + f"/pm/dataset_{day}.json")): D[r["mint"]] = r
sids = sorted({D[m]["sid"] for s in fol.values() for m in s if D[m]["sid"]})
print("tweets", len(sids), flush=True)
def one(sid):
    p = f"{SP}/dec/tweets/{sid}.json"
    if os.path.exists(p): return "have"
    for k in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(f"https://api.fxtwitter.com/status/{sid}", headers={"User-Agent": "Mozilla/5.0"}), timeout=20) as r:
                b = r.read()
            open(p, "wb").write(b); return "ok"
        except urllib.error.HTTPError as e:
            if e.code == 404: open(p, "w").write('{"code":404}'); return "404"
            time.sleep(2 + 3 * k)
        except Exception:
            time.sleep(2 + 3 * k)
    return "fail"
c = collections.Counter()
with ThreadPoolExecutor(4) as ex:
    for i, r in enumerate(ex.map(one, sids)):
        c[r] += 1
        if (i + 1) % 200 == 0: print(i + 1, dict(c), flush=True)
print("done", dict(c), flush=True)
