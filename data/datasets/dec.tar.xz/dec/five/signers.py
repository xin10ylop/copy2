# The launches our bot can fire on that neither wallet touched: every create of a signer in any operator table of the
# 5 days (the rule fires only on listed signers). -> five/extra_mints.txt (mints not in the union), five/signer_creates.json
import sys, json, os, glob, time, collections, threading
from concurrent.futures import ThreadPoolExecutor
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month"); sys.path.insert(0, SP + "/rivalpnl"); sys.path.insert(0, "/home/user/rugsnipe/analysis")
import tri, pumpparse as PP, common as C
tri.MIN_GAP = 0.01
F = SP + "/dec/five"
T0, T1 = 1792540800 - 600, int(time.time())
signers = set()
for p in glob.glob(F + "/replay/tables/*.json"): signers |= set(json.load(open(p)))
union = set(l.strip() for l in open(F + "/union.txt") if l.strip())
print("signers", len(signers), flush=True)
out = {}; lock = threading.Lock()
def one(s):
    found = []; before = None
    for _ in range(10):
        o = {"limit": 1000}
        if before: o["before"] = before
        ss = tri.rpc("getSignaturesForAddress", [s, o], cache=False) or []
        for x in ss:
            if not (T0 <= (x.get("blockTime") or 0) < T1) or x.get("err"): continue
            t = tri.tx(x["signature"])
            if not t: continue
            ks = PP.keys_of(t)
            if ks[0] != s: continue
            for prog, accs, data, parsed, oi, inner in PP._ixs(t, ks):
                if prog == C.PUMP and data and data[:8] in PP.IXR and PP.IXR[data[:8]].startswith("create") and accs:
                    found.append((accs[0], t["slot"], x["signature"]))
        if len(ss) < 1000 or (ss[-1].get("blockTime") or 0) < T0: break
        before = ss[-1]["signature"]
    with lock: out[s] = found
with ThreadPoolExecutor(10) as ex: list(ex.map(one, sorted(signers)))
allm = {m: (sl, sg) for v in out.values() for m, sl, sg in v}
extra = {m: v for m, v in allm.items() if m not in union}
print("creates by table signers", len(allm), "not in the union", len(extra), flush=True)
json.dump(dict(by_signer=out, extra=extra), open(F + "/signer_creates.json", "w"))
open(F + "/extra_mints.txt", "w").write("\n".join(sorted(extra)) + "\n")
