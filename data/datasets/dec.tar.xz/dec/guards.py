# His guard targets per attempt (slot window, the curve-state value) against the coin's real curve after each trade
# of its create slot. -> dec/night/guards.json
import sys, json, os, struct, collections
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
src = open(SP + "/dec/night.py").read()
exec(src.split("# 1. his attempts")[0])
ss, _ = sigs_range(A, TW, T1 + 3600, 100)
G = {}
for x in ss:
    t = tri.tx(x["signature"])
    if not t: continue
    ks = PP.keys_of(t); msg = t["transaction"]["message"]
    if ks[0] != A: continue
    m = None; buy = False
    for prog, accs, data, parsed, oi, inner in PP._ixs(t, ks):
        if prog == C.PUMP and not inner and data[:8] in PP.IXR and PP.IXR[data[:8]].startswith("buy"):
            buy = True; m = accs[2] if len(accs) > 2 else m
    if not buy or not m: continue
    g = dict(slot=t["slot"], idx=t.get("transactionIndex"), failed=(t.get("meta") or {}).get("err") is not None, err=str((t.get("meta") or {}).get("err"))[:60])
    for ix in msg["instructions"]:
        p = ks[ix["programIdIndex"]]; d = C.b58d(ix.get("data", ""))
        vals = [struct.unpack_from("<Q", d, i)[0] for i in range(0, len(d) - 7, 8)]
        if p.startswith("A5c1eN"): g["win"] = vals
        if p.startswith("8jzqTj"): g["curve"] = vals; g["curve_acc"] = [ks[a] for a in ix.get("accounts", [])]
    # the buy's own amounts (pump ix args)
    for prog, accs, data, parsed, oi, inner in PP._ixs(t, ks):
        if prog == C.PUMP and not inner and data[:8] in PP.IXR and PP.IXR[data[:8]].startswith("buy"):
            g["ix"] = PP.IXR[data[:8]]; g["args"] = [struct.unpack_from("<Q", data, i)[0] for i in range(8, min(len(data), 32) - 7, 8)]
    G.setdefault(m, g)
json.dump(G, open(OUT + "/guards.json", "w"))
print("attempts with guards", len(G), "with a curve guard", sum(1 for g in G.values() if "curve" in g))
# compare with the coin's curve: real token reserves after each create-slot trade
IV, IR = 1_073_000_000_000_000, 793_100_000_000_000
hit = collections.Counter(); ex = []
for m, g in G.items():
    p = f"{OUT}/coins/{m}.json"
    if "curve" not in g or not os.path.exists(p): continue
    t = json.load(open(p)); target = g["curve"][0]
    seq = [(s, i, e) for s, i, sg, evs in t["rows"] for e in evs if s == t["cs"]]
    states = [(i, e[0][:6], e[1], round(e[2] / 1e9, 3), e[5] - (IV - IR)) for s, i, e in seq]
    pos = next((k for k, st in enumerate(states) if st[4] == target), None)
    if pos is None:
        # maybe the virtual token reserves
        pos2 = next((k for k, (s, i, e) in enumerate(seq) if e[5] == target), None)
        hit["virtual match" if pos2 is not None else "no match"] += 1
        if len(ex) < 6 and pos2 is None: ex.append((m[:8], target, [(st[0], st[1], st[3], st[4]) for st in states[:8]]))
    else:
        # after which trade: count the trades before and whether the next trade is his
        nxt = states[pos + 1] if pos + 1 < len(states) else None
        hit[f"real match after trade {pos + 1} of the slot"] += 1
print(hit.most_common(12))
for e in ex: print(e)
