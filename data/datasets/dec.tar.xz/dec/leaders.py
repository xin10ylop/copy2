# The slot leader of every Oct 23 - Oct 24 12:00 create in the followed operators, its region, and his take by leader.
import sys, json, glob, collections, os
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month"); import tri
tri.MIN_GAP = 0.03
REG = json.load(open("/home/user/rugsnipe/data/leader_regions.json"))["regions"]
cr = {}
for f in glob.glob(SP + "/univ/creates_*.json"):
    for c in json.load(open(f)): cr[c["mint"]] = c
D = {}
for day in (23, 24):
    for r in json.load(open(SP + f"/pm/dataset_{day}.json")): D[r["mint"]] = r
fol = json.load(open(SP + "/dec/fol_ops_2324.json"))
ms = [m for s in fol.values() for m in s]
P = SP + "/dec/leaders_2324.json"
lead = json.load(open(P)) if os.path.exists(P) else {}
need = sorted({cr[m]["slot"] // 5000 * 5000 for m in ms} - {int(k) for k in lead})
for b in need:
    L = tri.rpc("getSlotLeaders", [b, 5000], cache=True) or []
    lead[str(b)] = L
json.dump(lead, open(P, "w"))
def leader(s): L = lead.get(str(s // 5000 * 5000)); return L[s % 5000] if L and s % 5000 < len(L) else None
st = collections.defaultdict(lambda: [0, 0]); byl = collections.defaultdict(lambda: [0, 0]); pos = collections.defaultdict(lambda: [0, 0])
for o, s in fol.items():
    for m in s:
        c = cr[m]; l = leader(c["slot"]); r = REG.get(l, "unknown"); he = D[m]["he"]
        st[r][0] += 1; st[r][1] += he; byl[l][0] += 1; byl[l][1] += he
        # position in the leader's 4-slot window
        p = (c["slot"] % 4); pos[p][0] += 1; pos[p][1] += he
print("followed operators' coins, his take by the create slot leader's region:")
for k, (n, h) in sorted(st.items(), key=lambda kv: -kv[1][0]): print(f"   {k:8s} coins {n:5d} he took {100*h/n:5.1f}%")
print("by the slot's position in the leader's 4-slot window:", {k: f"{100*h/n:.1f}% of {n}" for k, (n, h) in sorted(pos.items())})
lows = sorted(((h / n, n, l) for l, (n, h) in byl.items() if n >= 8), key=lambda x: x[0])
print("leaders with the lowest take (8+ coins):", [(f"{100*a:.0f}%", n, REG.get(l, "?"), (l or "-")[:8]) for a, n, l in lows[:12]])
print("leaders with the highest take:", [(f"{100*a:.0f}%", n, REG.get(l, "?"), (l or "-")[:8]) for a, n, l in lows[-8:]])
