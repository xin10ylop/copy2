# When did each night operator's bundle wallets start (their oldest transaction), who funded them first, and did he take
# the operator's first coins? -> dec/night/wstart.json
import sys, json, os, time, collections, threading
from concurrent.futures import ThreadPoolExecutor
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
src = open(SP + "/dec/night.py").read()
exec(src.split("# 1. his attempts")[0])
tri.MIN_GAP = 0.02
ops = json.load(open(OUT + "/ops.json"))
W = sorted({w for o, cs in ops.items() for m, c in cs.items() for w in c["wallets"]})
P = OUT + "/wstart.json"
S = json.load(open(P)) if os.path.exists(P) else {}
lock = threading.Lock()
def one(w):
    if w in S: return
    before = None; last = None; n = 0
    for page in range(30):
        o = {"limit": 1000}
        if before: o["before"] = before
        s = tri.rpc("getSignaturesForAddress", [w, o], cache=False) or []
        n += len(s)
        if s: last = s[-1]
        if len(s) < 1000: break
        before = s[-1]["signature"]
    first = dict(slot=last["slot"], bt=last.get("blockTime"), sig=last["signature"]) if last else None
    fund = None
    if last:
        t = tri.tx(last["signature"])
        if t:
            a = PP.analyze(t)
            ins = [(s_, lam / 1e9) for s_, d, lam, inner in a["sysxfers"] if d == w]
            fund = dict(signer=PP.keys_of(t)[0], inflow=ins[:3])
    with lock: S[w] = dict(n=n, capped=n >= 30000, first=first, fund=fund)
with ThreadPoolExecutor(6) as ex: list(ex.map(one, W))
json.dump(S, open(P, "w"))
log("wallet starts", len(S))
