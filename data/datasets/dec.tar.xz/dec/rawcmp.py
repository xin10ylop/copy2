# Raw anatomy of an operator's launches: create tx and the bundle txs (programs, compute price, tips, accounts, signers),
# for coins the insiders dumped at slot 0/1 (rugs) against the rest, operator J4o3bqXK (Oct 23-24).
import sys, json, os, glob, collections
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month"); sys.path.insert(0, SP + "/rivalpnl"); sys.path.insert(0, "/home/user/rugsnipe/analysis")
import tri, pumpparse as PP, common as C
fol = json.load(open(SP + "/dec/fol_ops_2324.json"))
cr = {}
for f in glob.glob(SP + "/univ/creates_*.json"):
    for c in json.load(open(f)): cr[c["mint"]] = c
D = {}
for day in (23, 24):
    for r in json.load(open(SP + f"/pm/dataset_{day}.json")): D[r["mint"]] = r
BW = json.load(open(SP + "/dec/bwall.json"))
def tape(m):
    for d in ("full", "fp"):
        p = f"{SP}/{d}/{m}.json"
        if os.path.exists(p): return json.load(open(p))
def ins_first(m):
    t = tape(m); c = cr[m]
    if not t: return None
    ins = {c["creator"], c["user"], c["signer"]} | set(BW.get(m, {}).get("bw", []))
    return next((s - c["slot"] for s, i, sg, evs in t["rows"] for e in evs if e[0] in ins and not e[1]), None)
def anatomy(m):
    c = cr[m]; t = tri.tx(c["sig"])
    ks = PP.keys_of(t); a = PP.analyze(t); msg = t["transaction"]["message"]
    progs = [ks[ix["programIdIndex"]][:6] for ix in msg["instructions"]]
    inner = sum(len(g["instructions"]) for g in (t["meta"].get("innerInstructions") or []))
    return dict(progs=progs, n_ix=len(progs), inner=inner, cup=a["cu_price"], cul=a["cu_limit"], tip=a["tip_total"], tips=a["tips"],
                nkeys=len(ks), nsig=msg["header"]["numRequiredSignatures"], alt=bool(t["meta"].get("loadedAddresses", {}).get("writable") or t["meta"].get("loadedAddresses", {}).get("readonly")),
                fee=t["meta"]["fee"], cu_used=t["meta"].get("computeUnitsConsumed"), uri=c["uri"][-30:], name=c["name"][:16], sym=c["symbol"][:10])
key = next(k for k in fol if k.startswith("J4o3bqXK")); s = fol[key]
rows = []
for m in s:
    f = ins_first(m)
    if f is None: continue
    rows.append((m, f, D[m]["he"], anatomy(m)))
rug = [r for r in rows if r[1] is not None and r[1] <= 1]; ok = [r for r in rows if r[1] is None or r[1] > 1]
print("rugs", len(rug), "taken", sum(r[2] for r in rug), "| others", len(ok), "taken", sum(r[2] for r in ok))
for lab, g in (("RUG", rug), ("OK", ok[:12])):
    for m, f, he, a in g:
        print(f"{lab:3s} {m[:8]} he {he} ins1st {f} cup {a['cup']} cul {a['cul']} tip {a['tip']} {list(a['tips'])} ix {a['progs']} inner {a['inner']} keys {a['nkeys']} sig {a['nsig']} alt {a['alt']} cu {a['cu_used']} | {a['sym']} {a['uri']}")
