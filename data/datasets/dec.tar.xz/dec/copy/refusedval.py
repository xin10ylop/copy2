# The live key's copies the 5% limit refuses: what they would have made filled at the price we would really have paid,
# and price limits keyed on his tip.
import json, collections
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
exec(open(SP + "/dec/copy/ablate.py").read().split("live = [r for r in rows")[0])
S2 = [r for r in rows if (r["tip"] >= 2e6 or r["sol"] >= 2.0) and cnt(r, 24) >= 2]
byd = collections.defaultdict(lambda: [0.0, 0.0, 0.0]); n_ref = 0
for r in S2:
    a = b = 0.0; k = 0; rf = 0
    for D in dec:
        en = entry_at(r, D)
        if not en: continue
        ex = exit_at(r["seq"], r["cs"], max(hold(r), 1), r["s"])
        v = pnl_s(en, ex, 0.5) if ex else None
        if v is None: continue
        k += 1
        if (en[0] / en[1]) / r["hisp"] - 1 > 0.05: b += v; rf += 1
        else: a += v
    if k:
        byd[r["day"]][0] += a / k; byd[r["day"]][1] += b / k; n_ref += rf / k
print("by day: " + " ".join(DAYS))
print(f"   copies under the 5% limit (filled):        total {sum(v[0] for v in byd.values()):+6.2f}  " + " ".join(f"{byd[d][0]:+.2f}" for d in DAYS))
print(f"   the refused ones ({n_ref:.0f}), filled anyway:    total {sum(v[1] for v in byd.values()):+6.2f}  " + " ".join(f"{byd[d][1]:+.2f}" for d in DAYS))
def lim(r): return 0.10 if r["tip"] >= 8e6 else 0.05
show("price limit 5%", S2)
show("price limit 7.5%", S2, prem=0.075)
show("no price limit", S2, prem=9.0)
for t, p in ((4e6, 0.10), (8e6, 0.10), (8e6, 0.15)):
    tot = collections.defaultdict(float); n = 0
    for r in S2:
        v = val(r, prem=p if r["tip"] >= t else 0.05)
        if v is None: continue
        tot[r["day"]] += v; n += 1
    print(f"   limit {p:.0%} when his tip >= {t/1e6:.0f}M, else 5%            n {n:4d} total {sum(tot.values()):+6.2f}  days+ {sum(1 for d in DAYS if tot[d] > 0)}/5  " + " ".join(f"{tot[d]:+5.2f}" for d in DAYS))
