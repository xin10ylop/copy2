# The operator rule under the live key (tip >= 2M or size >= 2 SOL): his buys split by his buys on the signer in the
# previous 24 h (0, 1, >= 2), his own net and the copy's (0.5 SOL, our landing distances, 5% bound) by day, with the
# live exit (table hold - 1, else his modal first sell - 1, else +9) and flat exits for the operators the table lacks.
import json, collections
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
exec(open(SP + "/dec/copy/ablate.py").read().split("live = [r for r in rows")[0])
K2 = [r for r in rows if r["tip"] >= 2e6 or r["sol"] >= 2.0]
print("by day: " + " ".join(DAYS))
for lab, f in (("0 buys before", lambda r: cnt(r, 24) == 0), ("1 buy before", lambda r: cnt(r, 24) == 1), (">= 2 before (live)", lambda r: cnt(r, 24) >= 2), ("all (rule off)", lambda r: True)):
    s = [r for r in K2 if f(r)]
    hb = collections.defaultdict(float)
    for r in s: hb[r["day"]] += r["his"]
    print(f"== {lab}: {len(s)} coins, listed in the 24 h tables {sum(r['listed'] for r in s)}; his own net {sum(r['his'] for r in s):+.2f} (" + " ".join(f"{hb[d]:+.2f}" for d in DAYS) + ")")
    show("copy, live exit", s)
    for h in (5, 7, 9):
        show(f"copy, flat create + {h}", s, hold_fn=lambda r, h=h: h)
