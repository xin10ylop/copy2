import json, collections
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
exec(open(SP + "/dec/copy/ablate.py").read().split("live = [r for r in rows")[0])
S2 = [r for r in rows if (r["tip"] >= 2e6 or r["sol"] >= 2.0) and cnt(r, 24) >= 2]
ref = fill = 0.0; vf = 0.0; n = 0
for r in S2:
    outs = []
    for D in dec:
        en = entry_at(r, D)
        if not en: continue
        if (en[0] / en[1]) / r["hisp"] - 1 > 0.05: outs.append(("ref", -0.0001)); continue
        ex = exit_at(r["seq"], r["cs"], max(hold(r), 1), r["s"])
        v = pnl_s(en, ex, 0.5) if ex else None
        if v is not None: outs.append(("fill", v))
    if not outs: continue
    n += 1
    ref += sum(1 for k, _ in outs if k == "ref") / len(outs)
    fill += sum(1 for k, _ in outs if k == "fill") / len(outs)
    vf += sum(v for k, v in outs if k == "fill") / len(outs)
print(f"{n} copies: refused by the 5% limit {ref:.0f} ({100 * ref / n:.0f}%), filled {fill:.0f}; the refused cost {ref * 0.0001:.4f} SOL in all, the filled made {vf:+.2f}")
